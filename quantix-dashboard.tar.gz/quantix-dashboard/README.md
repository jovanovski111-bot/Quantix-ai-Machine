# ⚡ Quantix — AI/ML Admin Dashboard

A premium enterprise-grade dashboard template for machine learning platforms, data scientists, and MLOps engineers. Built with Next.js 14, TypeScript, Tailwind CSS, and Recharts.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open in browser
open http://localhost:3000
```

---

## 🗂 Project Structure

```
quantix-dashboard/
├── src/
│   ├── app/
│   │   ├── layout.tsx              # Root layout (dark mode, fonts)
│   │   ├── page.tsx                # Redirect to /dashboard
│   │   └── dashboard/
│   │       ├── page.tsx            # 🏠 Main overview dashboard
│   │       ├── models/page.tsx     # 🧠 Model Analytics
│   │       ├── datasets/page.tsx   # 🗄  Dataset Management
│   │       ├── training/page.tsx   # ⚙️  Training Monitor
│   │       ├── predictions/page.tsx # 📊 Prediction Analytics
│   │       ├── gpu/page.tsx        # 🖥  GPU Monitor
│   │       ├── experiments/page.tsx # 🧪 Experiment Tracking
│   │       ├── users/page.tsx      # 👥 User Management
│   │       ├── api-keys/page.tsx   # 🔑 API Keys
│   │       ├── logs/page.tsx       # 📜 System Logs
│   │       ├── notifications/page.tsx # 🔔 Notifications
│   │       ├── billing/page.tsx    # 💳 Billing
│   │       └── settings/page.tsx   # ⚙️  Settings
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx         # Collapsible sidebar navigation
│   │   │   ├── TopNav.tsx          # Top bar (search, theme, notifications)
│   │   │   └── DashboardLayout.tsx # Wrapper layout
│   │   └── ui/
│   │       └── index.tsx           # 50+ reusable UI components
│   ├── lib/
│   │   ├── data.ts                 # All mock/sample data
│   │   └── utils.ts                # Utility helpers
│   └── styles/
│       └── globals.css             # Design tokens, CSS variables, animations
├── tailwind.config.ts
├── tsconfig.json
├── next.config.js
└── package.json
```

---

## 🎨 Design System

### Color Palette
| Color | CSS Variable | Usage |
|-------|-------------|-------|
| Violet | `--primary` | Primary actions, active states |
| Cyan | `--chart-2` | Secondary metrics, info |
| Emerald | `--chart-3` | Success, positive trends |
| Amber | `--chart-4` | Warnings, caution |
| Rose | `--chart-5` | Errors, danger |

### Typography
- **Display**: Syne — headers, titles
- **Body**: DM Sans — general text
- **Mono**: JetBrains Mono — code, metrics, IDs

### Theme
- Dark mode by default (persisted to localStorage)
- Toggle with the sun/moon button in the top nav
- CSS variables drive all colors — easily customizable

---

## 📦 Component Inventory (50+ components)

### Layout
- `DashboardLayout` — main wrapper
- `Sidebar` — collapsible nav with sections and badges
- `TopNav` — search modal (⌘K), theme toggle, notifications dropdown

### Core UI
| Component | Description |
|-----------|-------------|
| `Button` | 6 variants: default, secondary, outline, ghost, destructive, gradient |
| `Card` + CardHeader/Content/Footer | Flexible card system with glass/glow variants |
| `Badge` | 6 color variants |
| `MetricCard` | KPI card with icon, value, trend indicator |
| `StatusBadge` | Dynamic status indicator |
| `Progress` | Animated progress bars, 5 color variants |
| `Input` | With icon and suffix support |
| `Select` | Styled select dropdown |
| `Tabs` | Pill-style tab navigation |
| `Toggle` | Switch component |
| `Avatar` | Auto-colored initials avatar |
| `Tooltip` | Hover tooltip |
| `Table` + Head/Body/Row/Cell | Consistent table system |
| `Alert` | 4 types: info, success, warning, error |
| `Skeleton` | Loading placeholder |
| `Spinner` | Loading spinner |
| `Separator` | Horizontal/vertical divider |
| `EmptyState` | Empty list placeholder |
| `SectionHeader` | Page section header with action slot |
| `CopyButton` | One-click copy to clipboard |
| `Chip` | Removable tag/chip |

### Charts (via Recharts)
- Area charts (performance over time, predictions)
- Line charts (loss curves, ROC)
- Bar charts (model comparison, confidence distribution)
- Stacked bar charts
- Radar charts (experiment comparison)
- Custom tooltips

### Dashboard-specific
- Confusion Matrix heatmap
- Live Training Logs terminal
- Realtime Prediction Feed
- GPU Utilization Cards
- Experiment Leaderboard

---

## ⚡ Features

### ✅ Implemented
- [x] Dark / Light mode with localStorage persistence
- [x] Collapsible sidebar navigation
- [x] ⌘K command palette search
- [x] Notification dropdown with unread badges
- [x] Fully responsive (mobile → 4K)
- [x] 13 dashboard pages
- [x] 50+ reusable components
- [x] Live prediction feed (simulated real-time)
- [x] Training logs terminal
- [x] Interactive confusion matrix
- [x] Multi-experiment radar comparison
- [x] GPU monitoring with alert indicators
- [x] Dataset upload drop zone
- [x] API key generation UI

### 🔌 Extend with real data
Replace mock data in `src/lib/data.ts` with your API calls:
```typescript
// src/lib/api.ts
export async function fetchModelMetrics(modelId: string) {
  const res = await fetch(`/api/models/${modelId}/metrics`)
  return res.json()
}
```

---

## 🛠 Tech Stack

| Library | Version | Purpose |
|---------|---------|---------|
| Next.js | 14 | App Router, SSR |
| React | 18 | UI framework |
| TypeScript | 5 | Type safety |
| Tailwind CSS | 3.4 | Styling |
| Recharts | 2.12 | Charts |
| Lucide React | 0.383 | Icons |
| Google Fonts | — | Syne, DM Sans, JetBrains Mono |

---

## 📝 Customization Guide

### Adding a new page
1. Create `src/app/dashboard/my-page/page.tsx`
2. Add it to the nav in `src/components/layout/Sidebar.tsx`
3. Wrap content in `<DashboardLayout>`

### Changing the color scheme
Edit `src/styles/globals.css` CSS variables:
```css
:root {
  --primary: 262 83% 58%; /* violet */
  /* Change to any hue to rebrand */
}
```

### Adding real-time data
Use React's `useEffect` with polling or WebSockets:
```typescript
useEffect(() => {
  const interval = setInterval(() => {
    fetchLatestMetrics().then(setMetrics)
  }, 5000)
  return () => clearInterval(interval)
}, [])
```

---

## 📄 License
MIT — use freely in personal and commercial projects.

Built with ❤️ for the ML engineering community.
