'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, Badge, StatusBadge, SectionHeader, Button, Select,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Tabs
} from '@/components/ui'
import {
  LineChart, Line, BarChart, Bar, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ScatterChart, Scatter, Cell
} from 'recharts'
import {
  modelMetrics, performanceOverTime, rocCurveData,
  confusionMatrix, confusionLabels, modelVersions, modelComparison
} from '@/lib/data'
import { Brain, Download, RefreshCw, Plus, TrendingUp } from 'lucide-react'
import { cn } from '@/lib/utils'

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-xs">
      <p className="font-medium text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-mono font-medium">{typeof p.value === 'number' ? p.value.toFixed(3) : p.value}</span>
        </div>
      ))}
    </div>
  )
}

// Confusion matrix heatmap component
function ConfusionMatrix() {
  const max = Math.max(...confusionMatrix.flat())
  return (
    <div className="space-y-3">
      <div className="grid" style={{ gridTemplateColumns: `auto repeat(${confusionLabels.length}, 1fr)` }}>
        <div />
        {confusionLabels.map(l => (
          <div key={l} className="text-center text-[10px] text-muted-foreground font-medium pb-1 truncate">{l}</div>
        ))}
        {confusionMatrix.map((row, i) => (
          <React.Fragment key={i}>
            <div className="text-[10px] text-muted-foreground font-medium pr-2 flex items-center justify-end">{confusionLabels[i]}</div>
            {row.map((val, j) => {
              const opacity = 0.1 + (val / max) * 0.9
              const isDiag = i === j
              return (
                <div
                  key={j}
                  className={cn(
                    'aspect-square flex items-center justify-center m-0.5 rounded-md text-xs font-mono font-semibold transition-all',
                    isDiag ? 'text-white' : 'text-foreground'
                  )}
                  style={{
                    background: isDiag
                      ? `rgba(139, 92, 246, ${opacity})`
                      : `rgba(244, 63, 94, ${val / max * 0.4})`,
                  }}
                  title={`${confusionLabels[i]} → ${confusionLabels[j]}: ${val}`}
                >
                  {val}
                </div>
              )
            })}
          </React.Fragment>
        ))}
      </div>
    </div>
  )
}

const METRIC_ITEMS = [
  { label: 'Accuracy', value: modelMetrics.accuracy, color: 'violet' as const, format: '%' },
  { label: 'Precision', value: modelMetrics.precision, color: 'cyan' as const, format: '%' },
  { label: 'Recall', value: modelMetrics.recall, color: 'emerald' as const, format: '%' },
  { label: 'F1 Score', value: modelMetrics.f1Score, color: 'amber' as const, format: '%' },
]

export default function ModelsPage() {
  const [activeTab, setActiveTab] = useState('overview')

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'ML Platform' }, { label: 'Model Analytics' }]}>
      <SectionHeader
        title="Model Analytics"
        description="Track, compare, and manage your ML model performance"
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="h-3.5 w-3.5" /> Export
            </Button>
            <Button size="sm">
              <Plus className="h-3.5 w-3.5" /> Register Model
            </Button>
          </div>
        }
      />

      {/* Key Metrics */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {METRIC_ITEMS.map((m, i) => (
          <MetricCard
            key={m.label}
            label={m.label}
            value={`${m.value}${m.format}`}
            change={1.2}
            changeLabel="vs prev version"
            color={m.color}
            className={`stagger-${i + 1} opacity-0 animate-fade-in`}
          />
        ))}
      </div>

      {/* Tabs */}
      <Tabs
        tabs={[
          { id: 'overview', label: 'Overview' },
          { id: 'confusion', label: 'Confusion Matrix' },
          { id: 'roc', label: 'ROC Curve' },
          { id: 'comparison', label: 'Model Comparison' },
        ]}
        active={activeTab}
        onChange={setActiveTab}
        className="mb-6"
      />

      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {/* Loss + Accuracy curves */}
            <Card>
              <CardHeader>
                <CardTitle>Training vs Validation Accuracy</CardTitle>
                <CardDescription>Epoch-by-epoch performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceOverTime} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                      <XAxis dataKey="epoch" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} domain={[65, 100]} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="accuracy" stroke="#8b5cf6" strokeWidth={2} dot={false} name="Train Acc" />
                      <Line type="monotone" dataKey="valAccuracy" stroke="#06b6d4" strokeWidth={2} dot={false} name="Val Acc" strokeDasharray="4 2" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Loss curve */}
            <Card>
              <CardHeader>
                <CardTitle>Loss Curve</CardTitle>
                <CardDescription>Training & validation loss over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={performanceOverTime} margin={{ top: 5, right: 5, bottom: 0, left: -25 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                      <XAxis dataKey="epoch" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Line type="monotone" dataKey="loss" stroke="#f43f5e" strokeWidth={2} dot={false} name="Train Loss" />
                      <Line type="monotone" dataKey="valLoss" stroke="#f59e0b" strokeWidth={2} dot={false} name="Val Loss" strokeDasharray="4 2" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Model versions table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Model Registry</CardTitle>
                  <CardDescription>Version history and deployment status</CardDescription>
                </div>
                <Button variant="outline" size="sm"><RefreshCw className="h-3.5 w-3.5" /></Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Version</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Accuracy</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {modelVersions.map(model => (
                    <TableRow key={model.id}>
                      <TableCell className="font-mono font-semibold text-primary">{model.id}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{model.type}</Badge>
                      </TableCell>
                      <TableCell className="font-mono font-medium text-emerald-500">{model.accuracy}%</TableCell>
                      <TableCell className="text-muted-foreground">{model.size}</TableCell>
                      <TableCell className="text-muted-foreground">{model.created}</TableCell>
                      <TableCell><StatusBadge status={model.status} /></TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">Details</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'confusion' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Confusion Matrix</CardTitle>
              <CardDescription>Prediction vs actual class distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <ConfusionMatrix />
              <div className="mt-4 flex items-center gap-6 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <span className="h-3 w-3 rounded bg-violet-500/80" />
                  Correct predictions (diagonal)
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-3 w-3 rounded bg-rose-500/40" />
                  Misclassifications
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Per-Class Metrics</CardTitle>
              <CardDescription>Precision, recall, and F1 per class</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {confusionLabels.map((label, i) => {
                  const tp = confusionMatrix[i][i]
                  const total = confusionMatrix[i].reduce((a, b) => a + b, 0)
                  const precision = tp / confusionMatrix.reduce((a, row) => a + row[i], 0)
                  const recall = tp / total
                  const f1 = 2 * (precision * recall) / (precision + recall)
                  return (
                    <div key={label} className="p-3 rounded-lg bg-secondary/30 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{label}</span>
                        <Badge variant="info">F1: {(f1 * 100).toFixed(1)}%</Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div>
                          <p className="text-muted-foreground">Precision</p>
                          <p className="font-mono font-semibold text-violet-500">{(precision * 100).toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Recall</p>
                          <p className="font-mono font-semibold text-cyan-500">{(recall * 100).toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Samples</p>
                          <p className="font-mono font-semibold">{total.toLocaleString()}</p>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'roc' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>ROC Curve</CardTitle>
              <CardDescription>Receiver Operating Characteristic — AUC: 0.978</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={rocCurveData} margin={{ top: 5, right: 5, bottom: 20, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                    <XAxis dataKey="fpr" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} label={{ value: 'False Positive Rate', position: 'insideBottom', offset: -15, fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} label={{ value: 'True Positive Rate', angle: -90, position: 'insideLeft', offset: 15, fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="tpr" stroke="#8b5cf6" strokeWidth={2.5} dot={false} name="TPR" />
                    {/* Diagonal reference line */}
                    <Line
                      data={[{ fpr: 0, tpr: 0 }, { fpr: 1, tpr: 1 }]}
                      type="linear" dataKey="tpr" stroke="hsl(var(--muted-foreground))" strokeWidth={1}
                      strokeDasharray="4 4" dot={false} name="Random" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-3 p-3 rounded-lg bg-violet-500/10 border border-violet-500/20">
                <p className="text-sm font-medium text-violet-500">AUC = 0.978</p>
                <p className="text-xs text-muted-foreground mt-0.5">Excellent discriminative ability. Model significantly outperforms random baseline.</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Threshold Analysis</CardTitle>
              <CardDescription>Precision-Recall tradeoff at various thresholds</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[0.3, 0.5, 0.7, 0.8, 0.9, 0.95].map(threshold => {
                  const precision = 0.6 + threshold * 0.39
                  const recall = 0.99 - threshold * 0.6
                  const f1 = 2 * (precision * recall) / (precision + recall)
                  const isOptimal = threshold === 0.5
                  return (
                    <div key={threshold} className={cn(
                      'flex items-center gap-3 p-2.5 rounded-lg text-xs',
                      isOptimal ? 'bg-primary/10 border border-primary/20' : 'bg-secondary/30'
                    )}>
                      <span className="font-mono font-semibold w-8 flex-shrink-0">{threshold}</span>
                      <div className="flex-1 grid grid-cols-3 gap-2">
                        <div>
                          <p className="text-muted-foreground">Precision</p>
                          <p className="font-mono font-medium">{(precision * 100).toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Recall</p>
                          <p className="font-mono font-medium">{(recall * 100).toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">F1</p>
                          <p className="font-mono font-medium text-emerald-500">{(f1 * 100).toFixed(1)}%</p>
                        </div>
                      </div>
                      {isOptimal && <Badge variant="success">Optimal</Badge>}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'comparison' && (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Model Comparison</CardTitle>
              <CardDescription>Performance benchmarks across models</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={modelComparison} margin={{ top: 5, right: 5, bottom: 0, left: -20 }} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} domain={[70, 100]} />
                    <YAxis type="category" dataKey="model" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} width={110} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="accuracy" fill="#8b5cf6" radius={[0, 4, 4, 0]} name="Accuracy %" />
                    <Bar dataKey="f1" fill="#06b6d4" radius={[0, 4, 4, 0]} name="F1 %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Detailed Benchmarks</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Model</TableHead>
                    <TableHead>Accuracy</TableHead>
                    <TableHead>F1 Score</TableHead>
                    <TableHead>Latency (ms)</TableHead>
                    <TableHead>Size (GB)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {modelComparison.map((m, i) => (
                    <TableRow key={m.model}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {i === 0 && <Badge variant="success">Best</Badge>}
                          {m.model}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-emerald-500">{m.accuracy}%</TableCell>
                      <TableCell className="font-mono text-cyan-500">{m.f1}%</TableCell>
                      <TableCell className="font-mono">{m.latency}ms</TableCell>
                      <TableCell className="font-mono text-muted-foreground">{m.size} GB</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}
    </DashboardLayout>
  )
}
