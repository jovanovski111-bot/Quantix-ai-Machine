'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent,
  SectionHeader, Button, Badge, Input, Select
} from '@/components/ui'
import { systemLogs } from '@/lib/data'
import { ScrollText, Download, RefreshCw, Search, Filter } from 'lucide-react'
import { cn } from '@/lib/utils'

const LEVEL_STYLE: Record<string, string> = {
  INFO: 'text-cyan-500',
  WARN: 'text-amber-500',
  ERROR: 'text-rose-500',
  DEBUG: 'text-muted-foreground',
}

const LEVEL_BG: Record<string, string> = {
  INFO: 'bg-cyan-500/10',
  WARN: 'bg-amber-500/10',
  ERROR: 'bg-rose-500/10',
  DEBUG: 'bg-muted',
}

export default function LogsPage() {
  const [search, setSearch] = useState('')
  const [levelFilter, setLevelFilter] = useState('ALL')
  const [serviceFilter, setServiceFilter] = useState('all')
  const [autoRefresh, setAutoRefresh] = useState(true)

  const services = Array.from(new Set(systemLogs.map(l => l.service)))

  const filtered = systemLogs.filter(log => {
    const matchSearch = log.message.toLowerCase().includes(search.toLowerCase()) ||
      log.service.toLowerCase().includes(search.toLowerCase())
    const matchLevel = levelFilter === 'ALL' || log.level === levelFilter
    const matchService = serviceFilter === 'all' || log.service === serviceFilter
    return matchSearch && matchLevel && matchService
  })

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'Management' }, { label: 'System Logs' }]}>
      <SectionHeader
        title="System Logs"
        description="Real-time application and infrastructure logging"
        action={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className={cn('h-1.5 w-1.5 rounded-full', autoRefresh ? 'bg-emerald-500 animate-pulse' : 'bg-muted-foreground')} />
              {autoRefresh ? 'Live' : 'Paused'}
            </div>
            <Button variant="outline" size="sm" onClick={() => setAutoRefresh(!autoRefresh)}>
              {autoRefresh ? 'Pause' : 'Resume'}
            </Button>
            <Button variant="outline" size="sm"><Download className="h-3.5 w-3.5" /> Export</Button>
          </div>
        }
      />

      {/* Stats bar */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { level: 'INFO', count: systemLogs.filter(l => l.level === 'INFO').length, color: 'cyan' },
          { level: 'WARN', count: systemLogs.filter(l => l.level === 'WARN').length, color: 'amber' },
          { level: 'ERROR', count: systemLogs.filter(l => l.level === 'ERROR').length, color: 'rose' },
          { level: 'TOTAL', count: systemLogs.length, color: 'violet' },
        ].map(({ level, count, color }) => (
          <Card key={level} className="p-4 text-center cursor-pointer hover:bg-secondary/30 transition-colors" onClick={() => setLevelFilter(level === 'TOTAL' ? 'ALL' : level)}>
            <p className={cn('font-display text-2xl font-bold',
              color === 'cyan' ? 'text-cyan-500' :
              color === 'amber' ? 'text-amber-500' :
              color === 'rose' ? 'text-rose-500' : 'text-violet-500'
            )}>{count}</p>
            <p className="text-xs text-muted-foreground">{level}</p>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <Input
          icon={<Search className="h-3.5 w-3.5" />}
          placeholder="Search logs..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="max-w-xs"
        />
        <Select
          options={[
            { value: 'ALL', label: 'All Levels' },
            { value: 'INFO', label: 'INFO' },
            { value: 'WARN', label: 'WARN' },
            { value: 'ERROR', label: 'ERROR' },
          ]}
          value={levelFilter}
          onChange={e => setLevelFilter(e.target.value)}
        />
        <Select
          options={[
            { value: 'all', label: 'All Services' },
            ...services.map(s => ({ value: s, label: s }))
          ]}
          value={serviceFilter}
          onChange={e => setServiceFilter(e.target.value)}
        />
        <span className="text-xs text-muted-foreground">{filtered.length} entries</span>
      </div>

      {/* Log terminal */}
      <Card>
        <CardContent className="p-0">
          <div className="bg-[hsl(222,47%,4%)] rounded-xl overflow-hidden font-mono">
            {/* Terminal header */}
            <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5">
              <div className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-rose-500/80" />
                <span className="h-2.5 w-2.5 rounded-full bg-amber-500/80" />
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/80" />
              </div>
              <span className="text-xs text-white/30 flex-1 text-center">quantix-platform — system.log</span>
              <Button variant="ghost" size="sm" className="text-white/40 hover:text-white/80 h-6 px-2 text-xs">
                <RefreshCw className="h-3 w-3 mr-1" /> Refresh
              </Button>
            </div>

            {/* Log entries */}
            <div className="p-4 space-y-1 max-h-[500px] overflow-y-auto text-xs">
              {filtered.map(log => (
                <div key={log.id} className={cn(
                  'flex items-start gap-3 py-1 px-2 rounded-md transition-colors hover:bg-white/5 group',
                  log.level === 'ERROR' && 'bg-rose-500/5'
                )}>
                  <span className="text-white/30 flex-shrink-0 w-14">{log.time}</span>
                  <span className={cn('flex-shrink-0 font-bold w-11', LEVEL_STYLE[log.level])}>
                    {log.level}
                  </span>
                  <span className={cn(
                    'flex-shrink-0 text-[10px] px-1.5 py-0.5 rounded',
                    'text-white/40 bg-white/5 max-w-32 truncate'
                  )}>
                    {log.service}
                  </span>
                  <span className={cn(
                    'flex-1 leading-relaxed',
                    log.level === 'ERROR' ? 'text-rose-300' :
                    log.level === 'WARN' ? 'text-amber-300' :
                    'text-white/70'
                  )}>
                    {log.message}
                  </span>
                </div>
              ))}

              {/* Cursor */}
              {autoRefresh && (
                <div className="flex items-center gap-2 py-1 px-2 text-white/30">
                  <span className="animate-pulse">▊</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
