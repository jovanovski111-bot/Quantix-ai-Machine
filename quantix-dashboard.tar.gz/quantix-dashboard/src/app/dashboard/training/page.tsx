'use client'

import React, { useState, useEffect } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, Badge, StatusBadge, SectionHeader, Button, Progress, Alert,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell
} from '@/components/ui'
import {
  LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts'
import { trainingRuns, trainingLogs, performanceOverTime } from '@/lib/data'
import { Play, Pause, Square, Download, Terminal, RefreshCw, Clock, Zap, Activity } from 'lucide-react'
import { cn } from '@/lib/utils'

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-xs">
      <p className="font-medium text-muted-foreground mb-1">Epoch {label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-mono font-medium">{typeof p.value === 'number' ? p.value.toFixed(4) : p.value}</span>
        </div>
      ))}
    </div>
  )
}

export default function TrainingPage() {
  const [selectedRun, setSelectedRun] = useState(trainingRuns[0])
  const [autoScroll, setAutoScroll] = useState(true)
  const [logCount, setLogCount] = useState(trainingLogs.length)

  const activeRun = trainingRuns.find(r => r.status === 'running')

  // Simulate live log updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLogCount(prev => prev + 1)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'ML Platform' }, { label: 'Training' }]}>
      <SectionHeader
        title="Training Monitor"
        description="Real-time training pipeline monitoring and control"
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Download className="h-3.5 w-3.5" /> Export Logs
            </Button>
            <Button size="sm">
              <Play className="h-3.5 w-3.5" /> New Run
            </Button>
          </div>
        }
      />

      {activeRun && (
        <Alert type="info" className="mb-6" title="Active Training Run">
          {activeRun.model} (run-0091) is currently training — Epoch {activeRun.epoch}/{activeRun.totalEpochs} · Loss: {activeRun.loss} · Accuracy: {activeRun.accuracy}%
        </Alert>
      )}

      {/* KPI row */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Active Runs" value="1" color="cyan" icon={<Activity className="h-5 w-5" />} />
        <MetricCard label="Best Accuracy" value="94.7%" change={1.8} color="emerald" icon={<Zap className="h-5 w-5" />} />
        <MetricCard label="GPU Hours Used" value="847h" color="violet" icon={<Clock className="h-5 w-5" />} />
        <MetricCard label="Completed Today" value="3" color="amber" icon={<RefreshCw className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-4">
        {/* Run list */}
        <Card>
          <CardHeader>
            <CardTitle>Training Runs</CardTitle>
            <CardDescription>{trainingRuns.length} runs today</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {trainingRuns.map(run => (
              <div
                key={run.id}
                onClick={() => setSelectedRun(run)}
                className={cn(
                  'flex flex-col gap-2 p-4 border-b border-border/50 cursor-pointer transition-all hover:bg-secondary/30',
                  selectedRun.id === run.id && 'bg-primary/5 border-l-2 border-l-primary'
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-semibold text-primary">{run.id}</span>
                  <StatusBadge status={run.status} />
                </div>
                <p className="text-xs font-medium">{run.model}</p>
                <Progress
                  value={run.progress}
                  color={run.status === 'running' ? 'cyan' : run.status === 'completed' ? 'emerald' : 'rose'}
                  size="sm"
                />
                <div className="flex justify-between text-[10px] text-muted-foreground">
                  <span>Epoch {run.epoch}/{run.totalEpochs}</span>
                  <span>{run.gpu}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Charts */}
        <div className="xl:col-span-2 space-y-4">
          {/* Run detail */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>{selectedRun.model}</CardTitle>
                  <CardDescription>Run {selectedRun.id} · Started {selectedRun.started}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  {selectedRun.status === 'running' && (
                    <>
                      <Button variant="outline" size="icon" title="Pause">
                        <Pause className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="outline" size="icon" title="Stop">
                        <Square className="h-3.5 w-3.5" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-3 mb-4">
                {[
                  { label: 'Progress', value: `${selectedRun.progress}%`, color: 'text-cyan-500' },
                  { label: 'Loss', value: selectedRun.loss?.toFixed(4) ?? '—', color: 'text-rose-500' },
                  { label: 'Accuracy', value: selectedRun.accuracy ? `${selectedRun.accuracy}%` : '—', color: 'text-emerald-500' },
                  { label: 'LR', value: selectedRun.lr?.toExponential(1) ?? '—', color: 'text-amber-500' },
                ].map(stat => (
                  <div key={stat.label} className="bg-secondary/40 rounded-lg p-3 text-center">
                    <p className={cn('font-mono font-bold text-base', stat.color)}>{stat.value}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{stat.label}</p>
                  </div>
                ))}
              </div>
              <Progress value={selectedRun.progress} color={selectedRun.status === 'running' ? 'cyan' : selectedRun.status === 'completed' ? 'emerald' : 'rose'} size="lg" showLabel />
            </CardContent>
          </Card>

          {/* Loss & accuracy chart */}
          <Card>
            <CardHeader>
              <CardTitle>Live Metrics</CardTitle>
              <CardDescription>Loss & accuracy over epochs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={performanceOverTime} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                    <XAxis dataKey="epoch" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                    <YAxis yAxisId="acc" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} domain={[60, 100]} orientation="left" />
                    <YAxis yAxisId="loss" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} domain={[0, 1]} orientation="right" />
                    <Tooltip content={<CustomTooltip />} />
                    <Line yAxisId="acc" type="monotone" dataKey="accuracy" stroke="#8b5cf6" strokeWidth={2} dot={false} name="Accuracy" />
                    <Line yAxisId="loss" type="monotone" dataKey="loss" stroke="#f43f5e" strokeWidth={2} dot={false} name="Loss" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Training logs */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-muted-foreground" />
              <CardTitle>Training Logs</CardTitle>
              {selectedRun.status === 'running' && (
                <Badge variant="success" className="text-[10px]">LIVE</Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setAutoScroll(!autoScroll)}
                className={cn('text-xs font-medium px-2 py-1 rounded-md transition-colors', autoScroll ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:bg-secondary')}
              >
                Auto-scroll
              </button>
              <Button variant="outline" size="sm">
                <Download className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-[hsl(var(--background))] rounded-xl border border-border p-4 h-56 overflow-y-auto font-mono text-xs space-y-1">
            {trainingLogs.map((log, i) => (
              <div key={i} className="flex items-start gap-3 leading-5">
                <span className="text-muted-foreground/60 flex-shrink-0 w-16">{log.time}</span>
                <span className={cn(
                  'flex-shrink-0 font-semibold w-12',
                  log.level === 'INFO' ? 'text-cyan-500' :
                  log.level === 'WARN' ? 'text-amber-500' : 'text-rose-500'
                )}>{log.level}</span>
                <span className="text-foreground/80 break-all">{log.message}</span>
              </div>
            ))}
            {selectedRun.status === 'running' && (
              <div className="flex items-center gap-2 text-muted-foreground/60">
                <span className="animate-pulse">▊</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
