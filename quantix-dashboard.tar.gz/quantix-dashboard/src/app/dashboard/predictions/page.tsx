'use client'

import React, { useState, useEffect } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, Badge, StatusBadge, SectionHeader, Button,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Progress
} from '@/components/ui'
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from 'recharts'
import { predictionData, predictionTimeline, confidenceDistribution, realtimePredictions } from '@/lib/data'
import { TrendingUp, Zap, Clock, AlertCircle, Activity, RefreshCw } from 'lucide-react'
import { cn } from '@/lib/utils'

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-xs">
      <p className="font-medium text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-mono">{typeof p.value === 'number' ? p.value.toLocaleString() : p.value}</span>
        </div>
      ))}
    </div>
  )
}

const CONF_COLORS = confidenceDistribution.map((_, i) => {
  const t = i / (confidenceDistribution.length - 1)
  const r = Math.round(139 + (6 - 139) * t)
  const g = Math.round(92 + (182 - 92) * t)
  const b = Math.round(246 + (212 - 246) * t)
  return `rgb(${r},${g},${b})`
})

const LABEL_COLORS: Record<string, string> = {
  Positive: 'text-emerald-500 bg-emerald-500/10',
  Negative: 'text-rose-500 bg-rose-500/10',
  Neutral: 'text-amber-500 bg-amber-500/10',
}

export default function PredictionsPage() {
  const [feed, setFeed] = useState(realtimePredictions)
  const [live, setLive] = useState(true)

  useEffect(() => {
    if (!live) return
    const interval = setInterval(() => {
      const labels = ['Positive', 'Negative', 'Neutral'] as const
      const newPred = {
        id: `pred-${8822 + Math.floor(Math.random() * 100)}`,
        input: ['Amazing product, highly recommend!', 'Worst experience ever.', 'It was okay, nothing special.'][Math.floor(Math.random() * 3)],
        label: labels[Math.floor(Math.random() * 3)],
        confidence: 0.7 + Math.random() * 0.29,
        latency: 35 + Math.floor(Math.random() * 20),
        time: new Date().toLocaleTimeString(),
      }
      setFeed(prev => [newPred, ...prev.slice(0, 9)])
    }, 3000)
    return () => clearInterval(interval)
  }, [live])

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'ML Platform' }, { label: 'Predictions' }]}>
      <SectionHeader
        title="Prediction Analytics"
        description="Monitor prediction performance, confidence, and error rates"
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm"><RefreshCw className="h-3.5 w-3.5" /></Button>
          </div>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Total Predictions" value="2.85M" change={12.4} color="violet" icon={<TrendingUp className="h-5 w-5" />} />
        <MetricCard label="Success Rate" value={`${predictionData.successRate}%`} change={0.3} color="emerald" icon={<Zap className="h-5 w-5" />} />
        <MetricCard label="Avg Latency" value={`${predictionData.avgLatency}ms`} change={-4.1} color="cyan" icon={<Clock className="h-5 w-5" />} />
        <MetricCard label="Error Rate" value={`${predictionData.errorRate}%`} change={-0.3} color="rose" icon={<AlertCircle className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-4">
        {/* Prediction volume timeline */}
        <Card className="xl:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Prediction Volume (24h)</CardTitle>
                <CardDescription>Hourly request and error counts</CardDescription>
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-violet-500" />Predictions</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-rose-500" />Errors</span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={predictionTimeline} margin={{ top: 5, right: 5, bottom: 0, left: -10 }}>
                  <defs>
                    <linearGradient id="gradPred" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradErr" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                  <XAxis dataKey="hour" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="predictions" stroke="#8b5cf6" fill="url(#gradPred)" strokeWidth={2} dot={false} name="predictions" />
                  <Area type="monotone" dataKey="errors" stroke="#f43f5e" fill="url(#gradErr)" strokeWidth={2} dot={false} name="errors" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Confidence stats */}
        <Card>
          <CardHeader>
            <CardTitle>Confidence Score</CardTitle>
            <CardDescription>Distribution analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <p className="font-display text-3xl font-bold text-violet-500">
                {(predictionData.avgConfidence * 100).toFixed(1)}%
              </p>
              <p className="text-xs text-muted-foreground mt-1">Average confidence score</p>
            </div>
            <div className="space-y-1.5">
              {[
                { label: '> 90%', value: 65.8, color: 'emerald' as const },
                { label: '70–90%', value: 23.4, color: 'cyan' as const },
                { label: '50–70%', value: 7.9, color: 'amber' as const },
                { label: '< 50%', value: 2.9, color: 'rose' as const },
              ].map(band => (
                <div key={band.label}>
                  <div className="flex justify-between text-xs mb-0.5">
                    <span className="text-muted-foreground">{band.label}</span>
                    <span className="font-mono">{band.value}%</span>
                  </div>
                  <Progress value={band.value} color={band.color} size="sm" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confidence distribution chart */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-4">
        <Card>
          <CardHeader>
            <CardTitle>Confidence Distribution</CardTitle>
            <CardDescription>Count of predictions per confidence band</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={confidenceDistribution} margin={{ top: 5, right: 5, bottom: 0, left: -10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                  <XAxis dataKey="range" tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]} name="count">
                    {confidenceDistribution.map((_, i) => (
                      <Cell key={i} fill={CONF_COLORS[i]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Error rate over time */}
        <Card>
          <CardHeader>
            <CardTitle>Error Rate Trend</CardTitle>
            <CardDescription>24-hour rolling error percentage</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={predictionTimeline.map(d => ({
                    ...d,
                    errorRate: ((d.errors / d.predictions) * 100).toFixed(2),
                  }))}
                  margin={{ top: 5, right: 5, bottom: 0, left: -20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                  <XAxis dataKey="hour" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="errorRate" stroke="#f43f5e" strokeWidth={2} dot={false} name="Error %" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Realtime feed */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-muted-foreground" />
              <CardTitle>Live Prediction Feed</CardTitle>
              <Badge variant={live ? 'success' : 'outline'} className="text-[10px]">
                {live ? 'LIVE' : 'PAUSED'}
              </Badge>
            </div>
            <Button variant="outline" size="sm" onClick={() => setLive(!live)}>
              {live ? 'Pause Feed' : 'Resume Feed'}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Input</TableHead>
                <TableHead>Label</TableHead>
                <TableHead>Confidence</TableHead>
                <TableHead>Latency</TableHead>
                <TableHead>Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {feed.map(pred => (
                <TableRow key={pred.id} className="animate-fade-in">
                  <TableCell className="font-mono text-primary text-xs">{pred.id}</TableCell>
                  <TableCell className="max-w-48 truncate text-xs text-muted-foreground">{pred.input}</TableCell>
                  <TableCell>
                    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium', LABEL_COLORS[pred.label] ?? '')}>
                      {pred.label}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={pred.confidence * 100} color={pred.confidence > 0.9 ? 'emerald' : pred.confidence > 0.7 ? 'cyan' : 'amber'} size="sm" className="w-12" />
                      <span className="font-mono text-xs">{(pred.confidence * 100).toFixed(1)}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{pred.latency}ms</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">{pred.time}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
