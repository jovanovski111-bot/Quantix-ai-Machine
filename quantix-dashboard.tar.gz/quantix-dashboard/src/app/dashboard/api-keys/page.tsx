'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, Badge, StatusBadge, SectionHeader, Button, Alert,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
  CopyButton
} from '@/components/ui'
import { apiKeys } from '@/lib/data'
import { Key, Plus, Eye, EyeOff, Trash2, RefreshCw, Shield, Activity } from 'lucide-react'
import { cn, formatNumber } from '@/lib/utils'

export default function ApiKeysPage() {
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [newKeyVisible, setNewKeyVisible] = useState(false)

  const toggle = (id: string) => setShowKeys(prev => ({ ...prev, [id]: !prev[id] }))

  const maskKey = (key: string) => key.replace(/(?<=^.{12}).*(?=.{4}$)/, '••••••••••••')

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'Management' }, { label: 'API Keys' }]}>
      <SectionHeader
        title="API Keys"
        description="Manage API credentials and access scopes"
        action={
          <Button size="sm" onClick={() => setNewKeyVisible(true)}>
            <Plus className="h-3.5 w-3.5" /> Generate Key
          </Button>
        }
      />

      <Alert type="warning" className="mb-6" title="Security Notice">
        API keys grant programmatic access to your Quantix resources. Never share keys publicly or commit them to version control.
      </Alert>

      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Active Keys" value={apiKeys.filter(k => k.status === 'active').length} color="emerald" icon={<Key className="h-5 w-5" />} />
        <MetricCard label="Total Requests" value="3.88M" color="violet" icon={<Activity className="h-5 w-5" />} />
        <MetricCard label="Revoked" value={apiKeys.filter(k => k.status === 'revoked').length} color="rose" icon={<Shield className="h-5 w-5" />} />
        <MetricCard label="Scopes Active" value="4" color="cyan" icon={<Key className="h-5 w-5" />} />
      </div>

      {newKeyVisible && (
        <Card className="mb-6 border-primary/30 bg-primary/5">
          <CardHeader>
            <CardTitle>New API Key Generated</CardTitle>
            <CardDescription>Copy this key now — it will not be shown again</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3 p-3 bg-background/80 rounded-lg border border-border font-mono text-sm">
              <span className="flex-1 text-emerald-500">qx_live_k9x2m8p4n1q7r3s6t0w5y8z2a4b6c8d0e2f4g6h8i0j2k4</span>
              <CopyButton text="qx_live_k9x2m8p4n1q7r3s6t0w5y8z2a4b6c8d0e2f4g6h8i0j2k4" />
            </div>
            <div className="flex items-center justify-between mt-3">
              <p className="text-xs text-muted-foreground">⚠️ Store this in a secure location such as an environment variable or secret manager.</p>
              <Button variant="outline" size="sm" onClick={() => setNewKeyVisible(false)}>Done</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Key</TableHead>
                <TableHead>Scope</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Requests</TableHead>
                <TableHead>Last Used</TableHead>
                <TableHead>Created</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {apiKeys.map(key => (
                <TableRow key={key.id} className={cn(key.status === 'revoked' && 'opacity-50')}>
                  <TableCell className="font-medium text-sm">{key.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <code className="font-mono text-xs bg-secondary/60 px-2 py-0.5 rounded">
                        {showKeys[key.id] ? key.key : maskKey(key.key)}
                      </code>
                      <button
                        onClick={() => toggle(key.id)}
                        className="text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {showKeys[key.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={key.scope === 'full' ? 'error' : 'info'}>{key.scope}</Badge>
                  </TableCell>
                  <TableCell><StatusBadge status={key.status} /></TableCell>
                  <TableCell className="font-mono text-sm">{formatNumber(key.requests)}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{key.lastUsed}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{key.created}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {key.status === 'active' && (
                        <Button variant="ghost" size="icon" className="h-7 w-7" title="Rotate key">
                          <RefreshCw className="h-3.5 w-3.5" />
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
