'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardContent,
  MetricCard, SectionHeader, Button, Badge
} from '@/components/ui'
import { notifications } from '@/lib/data'
import { Bell, Check, CheckCheck, Trash2, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'

const TYPE_ICONS: Record<string, string> = {
  success: '✅',
  warning: '⚠️',
  error: '🚨',
  info: 'ℹ️',
}

const TYPE_COLORS: Record<string, string> = {
  success: 'border-l-emerald-500 bg-emerald-500/5',
  warning: 'border-l-amber-500 bg-amber-500/5',
  error: 'border-l-rose-500 bg-rose-500/5',
  info: 'border-l-cyan-500 bg-cyan-500/5',
}

export default function NotificationsPage() {
  const [notifs, setNotifs] = useState(notifications)
  const [filter, setFilter] = useState<'all' | 'unread' | 'error' | 'warning'>('all')

  const markAll = () => setNotifs(prev => prev.map(n => ({ ...n, read: true })))
  const markRead = (id: number) => setNotifs(prev => prev.map(n => n.id === id ? { ...n, read: true } : n))
  const remove = (id: number) => setNotifs(prev => prev.filter(n => n.id !== id))

  const filtered = notifs.filter(n => {
    if (filter === 'unread') return !n.read
    if (filter === 'error') return n.type === 'error'
    if (filter === 'warning') return n.type === 'warning'
    return true
  })

  const unread = notifs.filter(n => !n.read).length

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'Management' }, { label: 'Notifications' }]}>
      <SectionHeader
        title="Notifications"
        description="Stay updated on platform events and alerts"
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={markAll}>
              <CheckCheck className="h-3.5 w-3.5" /> Mark all read
            </Button>
            <Button variant="outline" size="sm">
              <Settings className="h-3.5 w-3.5" /> Preferences
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-4 gap-4 mb-6">
        <MetricCard label="Unread" value={unread} color="rose" icon={<Bell className="h-5 w-5" />} />
        <MetricCard label="Errors" value={notifs.filter(n => n.type === 'error').length} color="rose" icon={<Bell className="h-5 w-5" />} />
        <MetricCard label="Warnings" value={notifs.filter(n => n.type === 'warning').length} color="amber" icon={<Bell className="h-5 w-5" />} />
        <MetricCard label="Total" value={notifs.length} color="violet" icon={<Bell className="h-5 w-5" />} />
      </div>

      {/* Filter tabs */}
      <div className="flex items-center gap-2 mb-4">
        {(['all', 'unread', 'error', 'warning'] as const).map(f => (
          <Button
            key={f}
            variant={filter === f ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(f)}
            className="capitalize"
          >
            {f}
            {f === 'unread' && unread > 0 && (
              <Badge variant="error" className="ml-1.5 text-[10px] h-4 px-1">{unread}</Badge>
            )}
          </Button>
        ))}
      </div>

      <div className="space-y-2">
        {filtered.length === 0 ? (
          <Card className="p-12 text-center">
            <Bell className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">No notifications in this category</p>
          </Card>
        ) : (
          filtered.map(notif => (
            <div
              key={notif.id}
              className={cn(
                'flex items-start gap-4 p-4 rounded-xl border-l-2 border border-border transition-all group',
                TYPE_COLORS[notif.type],
                !notif.read && 'shadow-sm'
              )}
            >
              <span className="text-lg flex-shrink-0 mt-0.5">{TYPE_ICONS[notif.type]}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="text-sm font-semibold">{notif.title}</p>
                  {!notif.read && <span className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />}
                </div>
                <p className="text-xs text-muted-foreground">{notif.message}</p>
                <p className="text-[10px] text-muted-foreground/60 mt-1.5">{notif.time}</p>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                {!notif.read && (
                  <Button variant="ghost" size="icon" className="h-7 w-7" title="Mark as read" onClick={() => markRead(notif.id)}>
                    <Check className="h-3.5 w-3.5" />
                  </Button>
                )}
                <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => remove(notif.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </DashboardLayout>
  )
}
