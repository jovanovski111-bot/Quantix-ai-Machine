'use client'

import React, { useState, useEffect } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, Badge, StatusBadge, SectionHeader, Button, Progress, Alert
} from '@/components/ui'
import {
  AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts'
import { gpuData, gpuTimeline, gpuMemoryTimeline } from '@/lib/data'
import { Cpu, Thermometer, Zap, HardDrive, AlertTriangle, RefreshCw } from 'lucide-react'
import { cn } from '@/lib/utils'

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-xs">
      <p className="font-medium text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-mono font-medium">{typeof p.value === 'number' ? p.value.toFixed(1) : p.value}%</span>
        </div>
      ))}
    </div>
  )
}

function GpuCard({ gpu }: { gpu: typeof gpuData[0] }) {
  const isHot = gpu.temperature > 70
  const isMaxUtil = gpu.utilization > 90

  return (
    <Card className={cn('p-4', isMaxUtil && 'border-amber-500/30')}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="font-mono text-xs font-bold">{gpu.name}</p>
          <StatusBadge status={gpu.status} />
        </div>
        <div className="flex items-center gap-1.5">
          {isHot && <Thermometer className="h-3.5 w-3.5 text-amber-500" />}
          {isMaxUtil && <AlertTriangle className="h-3.5 w-3.5 text-rose-500" />}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="text-center bg-secondary/40 rounded-lg p-2">
          <p className={cn('font-display text-lg font-bold', isMaxUtil ? 'text-rose-500' : 'text-cyan-500')}>
            {gpu.utilization}%
          </p>
          <p className="text-[10px] text-muted-foreground">Utilization</p>
        </div>
        <div className="text-center bg-secondary/40 rounded-lg p-2">
          <p className={cn('font-display text-lg font-bold', isHot ? 'text-amber-500' : 'text-emerald-500')}>
            {gpu.temperature}°C
          </p>
          <p className="text-[10px] text-muted-foreground">Temperature</p>
        </div>
      </div>

      <div className="space-y-2">
        <div>
          <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
            <span className="flex items-center gap-1"><Cpu className="h-2.5 w-2.5" /> GPU Load</span>
            <span className="font-mono">{gpu.utilization}%</span>
          </div>
          <Progress value={gpu.utilization} color={gpu.utilization > 90 ? 'rose' : gpu.utilization > 70 ? 'amber' : 'cyan'} size="sm" />
        </div>
        <div>
          <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
            <span className="flex items-center gap-1"><HardDrive className="h-2.5 w-2.5" /> VRAM</span>
            <span className="font-mono">{gpu.vram}%</span>
          </div>
          <Progress value={gpu.vram} color={gpu.vram > 90 ? 'rose' : 'violet'} size="sm" />
        </div>
        <div>
          <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
            <span className="flex items-center gap-1"><Zap className="h-2.5 w-2.5" /> Power</span>
            <span className="font-mono">{gpu.power}W</span>
          </div>
          <Progress value={(gpu.power / 400) * 100} color="amber" size="sm" />
        </div>
      </div>
    </Card>
  )
}

export default function GpuPage() {
  const [data, setData] = useState(gpuTimeline)
  const hotGpus = gpuData.filter(g => g.temperature > 70)
  const activeGpus = gpuData.filter(g => g.status === 'active')
  const avgUtil = Math.round(activeGpus.reduce((a, g) => a + g.utilization, 0) / activeGpus.length)

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'ML Platform' }, { label: 'GPU Monitor' }]}>
      <SectionHeader
        title="GPU Monitor"
        description="Real-time GPU infrastructure monitoring"
        action={
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live — updates every 5s
            </div>
            <Button variant="outline" size="sm">
              <RefreshCw className="h-3.5 w-3.5" /> Refresh
            </Button>
          </div>
        }
      />

      {hotGpus.length > 0 && (
        <Alert type="warning" className="mb-6" title={`Temperature Warning — ${hotGpus.length} GPU${hotGpus.length > 1 ? 's' : ''}`}>
          {hotGpus.map(g => g.name).join(', ')} running above 70°C. Consider monitoring for thermal throttling.
        </Alert>
      )}

      {/* KPI strip */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Active GPUs" value={`${activeGpus.length}/${gpuData.length}`} color="emerald" icon={<Cpu className="h-5 w-5" />} />
        <MetricCard label="Avg Utilization" value={`${avgUtil}%`} change={-3.2} color="cyan" icon={<Zap className="h-5 w-5" />} />
        <MetricCard label="Max Temperature" value={`${Math.max(...gpuData.map(g => g.temperature))}°C`} color="amber" icon={<Thermometer className="h-5 w-5" />} />
        <MetricCard label="Total Power" value={`${gpuData.reduce((a, g) => a + g.power, 0)}W`} color="violet" icon={<Zap className="h-5 w-5" />} />
      </div>

      {/* GPU cards grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
        {gpuData.map(gpu => (
          <GpuCard key={gpu.name} gpu={gpu} />
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>GPU Utilization Timeline</CardTitle>
            <CardDescription>30-minute rolling window</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={gpuTimeline} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                  <defs>
                    {['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'].map((color, i) => (
                      <linearGradient key={i} id={`grad${i}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={color} stopOpacity={0.25} />
                        <stop offset="95%" stopColor={color} stopOpacity={0} />
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                  <XAxis dataKey="time" tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} domain={[0, 100]} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="A100-0" stroke="#8b5cf6" fill="url(#grad0)" strokeWidth={1.5} dot={false} />
                  <Area type="monotone" dataKey="A100-1" stroke="#06b6d4" fill="url(#grad1)" strokeWidth={1.5} dot={false} />
                  <Area type="monotone" dataKey="A100-2" stroke="#10b981" fill="url(#grad2)" strokeWidth={1.5} dot={false} />
                  <Area type="monotone" dataKey="V100-0" stroke="#f59e0b" fill="url(#grad3)" strokeWidth={1.5} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Memory Usage</CardTitle>
            <CardDescription>Cluster VRAM utilization</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={gpuMemoryTimeline} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="gradUsed" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradFree" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                  <XAxis dataKey="time" tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 9, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="used" stroke="#8b5cf6" fill="url(#gradUsed)" strokeWidth={2} dot={false} name="Used %" />
                  <Area type="monotone" dataKey="free" stroke="#10b981" fill="url(#gradFree)" strokeWidth={2} dot={false} name="Free %" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
