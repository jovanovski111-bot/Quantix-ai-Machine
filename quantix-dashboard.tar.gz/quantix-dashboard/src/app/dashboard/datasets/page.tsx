'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, Badge, StatusBadge, SectionHeader, Button, Progress,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
  Input, Chip, EmptyState, Alert
} from '@/components/ui'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from 'recharts'
import { datasets, columnStats, classDistribution } from '@/lib/data'
import {
  Database, Upload, Search, Filter, Eye, Trash2, Tag,
  FileText, MoreHorizontal, Plus, RefreshCw
} from 'lucide-react'
import { cn, formatNumber, getStatusBg } from '@/lib/utils'

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-xs">
      <p className="font-medium mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
          <span className="font-mono">{p.value.toLocaleString()}</span>
        </div>
      ))}
    </div>
  )
}

const DIST_COLORS = ['#8b5cf6', '#06b6d4', '#10b981']

export default function DatasetsPage() {
  const [search, setSearch] = useState('')
  const [selectedDataset, setSelectedDataset] = useState(datasets[0])
  const [showUpload, setShowUpload] = useState(false)
  const [dragOver, setDragOver] = useState(false)

  const filtered = datasets.filter(d =>
    d.name.toLowerCase().includes(search.toLowerCase()) ||
    d.type.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'ML Platform' }, { label: 'Datasets' }]}>
      <SectionHeader
        title="Dataset Management"
        description="Manage, version, and analyze your training datasets"
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowUpload(!showUpload)}>
              <Upload className="h-3.5 w-3.5" /> Upload Dataset
            </Button>
            <Button size="sm">
              <Plus className="h-3.5 w-3.5" /> New Dataset
            </Button>
          </div>
        }
      />

      {/* Upload drop zone */}
      {showUpload && (
        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true) }}
          onDragLeave={() => setDragOver(false)}
          onDrop={e => { e.preventDefault(); setDragOver(false) }}
          className={cn(
            'border-2 border-dashed rounded-2xl p-10 text-center mb-6 transition-all cursor-pointer',
            dragOver
              ? 'border-primary bg-primary/10'
              : 'border-border hover:border-primary/50 hover:bg-secondary/30'
          )}
        >
          <div className="flex flex-col items-center gap-3">
            <div className="h-12 w-12 rounded-2xl bg-violet-500/10 flex items-center justify-center">
              <Upload className="h-6 w-6 text-violet-500" />
            </div>
            <div>
              <p className="font-semibold text-sm">Drop files here or click to browse</p>
              <p className="text-xs text-muted-foreground mt-1">Supports CSV, Parquet, JSON, HDF5, ZIP — max 500 GB</p>
            </div>
            <Button variant="outline" size="sm">Browse Files</Button>
          </div>
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Total Datasets" value={datasets.length} color="violet" icon={<Database className="h-5 w-5" />} />
        <MetricCard label="Ready" value={datasets.filter(d => d.status === 'ready').length} color="emerald" icon={<FileText className="h-5 w-5" />} />
        <MetricCard label="Total Records" value="3.03M" color="cyan" icon={<Database className="h-5 w-5" />} />
        <MetricCard label="Storage Used" value="162 GB" change={8.4} color="amber" icon={<Database className="h-5 w-5" />} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Dataset list */}
        <div className="space-y-3">
          <Input
            icon={<Search className="h-3.5 w-3.5" />}
            placeholder="Search datasets..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <div className="space-y-2">
            {filtered.map(ds => (
              <Card
                key={ds.id}
                onClick={() => setSelectedDataset(ds)}
                className={cn(
                  'p-4 cursor-pointer transition-all hover:bg-secondary/30',
                  selectedDataset.id === ds.id && 'border-primary/40 bg-primary/5'
                )}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold truncate">{ds.name}</p>
                    <p className="text-[10px] text-muted-foreground font-mono">{ds.id} · {ds.version}</p>
                  </div>
                  <StatusBadge status={ds.status} />
                </div>
                <div className="flex items-center gap-2 flex-wrap mb-2">
                  <Badge variant="outline" className="text-[10px]">{ds.type}</Badge>
                  {ds.tags.slice(0, 2).map(tag => (
                    <Badge key={tag} variant="default" className="text-[10px]">{tag}</Badge>
                  ))}
                </div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>{formatNumber(ds.records)} records · {ds.features} features</span>
                  <span>{ds.size}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Dataset detail */}
        <div className="xl:col-span-2 space-y-4">
          {/* Header */}
          <Card>
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="font-display font-bold">{selectedDataset.name}</h2>
                    <StatusBadge status={selectedDataset.status} />
                  </div>
                  <p className="text-sm text-muted-foreground">{selectedDataset.id} · Created {selectedDataset.created}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm"><Eye className="h-3.5 w-3.5" /> Preview</Button>
                  <Button variant="outline" size="sm"><Tag className="h-3.5 w-3.5" /> Tag</Button>
                  <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></Button>
                </div>
              </div>

              <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
                {[
                  { label: 'Records', value: formatNumber(selectedDataset.records) },
                  { label: 'Features', value: selectedDataset.features },
                  { label: 'Size', value: selectedDataset.size },
                  { label: 'Missing Values', value: `${selectedDataset.missingValues}%`, warn: selectedDataset.missingValues > 5 },
                ].map(stat => (
                  <div key={stat.label} className="bg-secondary/40 rounded-lg p-3">
                    <p className={cn('font-mono font-bold text-sm', stat.warn ? 'text-amber-500' : 'text-foreground')}>
                      {stat.value}
                    </p>
                    <p className="text-[10px] text-muted-foreground">{stat.label}</p>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-1.5 mt-4">
                {selectedDataset.tags.map(tag => (
                  <Chip key={tag} label={tag} />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Class distribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Class Distribution</CardTitle>
                <CardDescription>Label balance analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={classDistribution} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                      <XAxis dataKey="label" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                        {classDistribution.map((_, i) => (
                          <Cell key={i} fill={DIST_COLORS[i % DIST_COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-3 space-y-1.5">
                  {classDistribution.map((cls, i) => (
                    <div key={cls.label} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full" style={{ background: DIST_COLORS[i] }} />
                        <span>{cls.label}</span>
                      </div>
                      <span className="font-mono text-muted-foreground">{cls.percentage}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Missing values analysis */}
            <Card>
              <CardHeader>
                <CardTitle>Data Quality</CardTitle>
                <CardDescription>Coverage by column</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2.5 max-h-52 overflow-y-auto pr-1">
                  {columnStats.map(col => (
                    <div key={col.name}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-mono font-medium truncate">{col.name}</span>
                        <span className="text-muted-foreground flex-shrink-0">{col.coverage}%</span>
                      </div>
                      <Progress
                        value={col.coverage}
                        color={col.coverage === 100 ? 'emerald' : col.coverage > 95 ? 'cyan' : 'amber'}
                        size="sm"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Column stats table */}
          <Card>
            <CardHeader>
              <CardTitle>Column Statistics</CardTitle>
              <CardDescription>Schema and data profile</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Column</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Unique Values</TableHead>
                    <TableHead>Missing</TableHead>
                    <TableHead>Coverage</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {columnStats.map(col => (
                    <TableRow key={col.name}>
                      <TableCell className="font-mono font-medium text-primary">{col.name}</TableCell>
                      <TableCell><Badge variant="outline">{col.type}</Badge></TableCell>
                      <TableCell className="font-mono">{formatNumber(col.unique)}</TableCell>
                      <TableCell>
                        <span className={cn(
                          'font-mono',
                          col.missing === 0 ? 'text-emerald-500' : col.missing < 3 ? 'text-amber-500' : 'text-rose-500'
                        )}>
                          {col.missing}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={col.coverage} color={col.coverage > 97 ? 'emerald' : 'amber'} size="sm" className="w-16" />
                          <span className="font-mono text-xs">{col.coverage}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
