'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  SectionHeader, Button, Input, Toggle, Badge, Tabs, Avatar, Separator
} from '@/components/ui'
import { Settings, User, Bell, Shield, Palette, Globe, Save } from 'lucide-react'

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('profile')
  const [saved, setSaved] = useState(false)
  const [notifs, setNotifs] = useState({
    trainingComplete: true,
    modelDeployed: true,
    gpuAlert: true,
    weeklyReport: false,
    apiLimitWarning: true,
    teamActivity: false,
  })

  const save = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'Account' }, { label: 'Settings' }]}>
      <SectionHeader
        title="Settings"
        description="Configure your account, notifications, and platform preferences"
        action={
          <Button size="sm" onClick={save}>
            <Save className="h-3.5 w-3.5" />
            {saved ? '✓ Saved!' : 'Save Changes'}
          </Button>
        }
      />

      <Tabs
        tabs={[
          { id: 'profile', label: 'Profile', icon: <User className="h-3.5 w-3.5" /> },
          { id: 'notifications', label: 'Notifications', icon: <Bell className="h-3.5 w-3.5" /> },
          { id: 'security', label: 'Security', icon: <Shield className="h-3.5 w-3.5" /> },
          { id: 'appearance', label: 'Appearance', icon: <Palette className="h-3.5 w-3.5" /> },
        ]}
        active={activeTab}
        onChange={setActiveTab}
        className="mb-6"
      />

      {activeTab === 'profile' && (
        <div className="space-y-4 max-w-2xl">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>Update your personal details and display preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar initials="EV" size="lg" />
                <div>
                  <p className="text-sm font-medium">Profile Photo</p>
                  <p className="text-xs text-muted-foreground">JPG, GIF, or PNG. Max 2MB.</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Button variant="outline" size="sm">Upload</Button>
                    <Button variant="ghost" size="sm" className="text-destructive">Remove</Button>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">First Name</label>
                  <Input defaultValue="Elena" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Last Name</label>
                  <Input defaultValue="Vasquez" />
                </div>
                <div className="space-y-1.5 col-span-2">
                  <label className="text-xs font-medium text-muted-foreground">Email Address</label>
                  <Input defaultValue="e.vasquez@quantix.ai" type="email" />
                </div>
                <div className="space-y-1.5 col-span-2">
                  <label className="text-xs font-medium text-muted-foreground">Job Title</label>
                  <Input defaultValue="Lead ML Engineer" />
                </div>
                <div className="space-y-1.5 col-span-2">
                  <label className="text-xs font-medium text-muted-foreground">Bio</label>
                  <textarea
                    defaultValue="Building production ML systems at Quantix. Specializing in NLP and transformer architectures."
                    className="w-full min-h-20 rounded-lg border border-input bg-secondary/50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring transition-all resize-none"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Team & Organization</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Organization</label>
                  <Input defaultValue="Quantix AI" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Team</label>
                  <Input defaultValue="Core ML" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Role</label>
                  <Input defaultValue="Admin" disabled className="opacity-60" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Timezone</label>
                  <Input defaultValue="UTC-8 (Pacific)" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'notifications' && (
        <div className="space-y-4 max-w-2xl">
          <Card>
            <CardHeader>
              <CardTitle>Email Notifications</CardTitle>
              <CardDescription>Configure which events trigger email alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { key: 'trainingComplete', label: 'Training run completed', desc: 'When a training job finishes successfully or fails' },
                  { key: 'modelDeployed', label: 'Model deployed', desc: 'When a model version is pushed to production' },
                  { key: 'gpuAlert', label: 'GPU temperature alerts', desc: 'When GPU temperature exceeds threshold' },
                  { key: 'weeklyReport', label: 'Weekly performance report', desc: 'Summary of model metrics and usage every Monday' },
                  { key: 'apiLimitWarning', label: 'API limit warnings', desc: 'When approaching monthly API quota limits' },
                  { key: 'teamActivity', label: 'Team activity digest', desc: 'Daily summary of team model and experiment activity' },
                ].map(({ key, label, desc }) => (
                  <div key={key} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                    <div>
                      <p className="text-sm font-medium">{label}</p>
                      <p className="text-xs text-muted-foreground">{desc}</p>
                    </div>
                    <Toggle
                      checked={notifs[key as keyof typeof notifs]}
                      onChange={val => setNotifs(prev => ({ ...prev, [key]: val }))}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'security' && (
        <div className="space-y-4 max-w-2xl">
          <Card>
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Current Password</label>
                <Input type="password" placeholder="••••••••" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">New Password</label>
                <Input type="password" placeholder="Min 12 characters" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Confirm Password</label>
                <Input type="password" placeholder="••••••••" />
              </div>
              <Button size="sm" className="mt-2">Update Password</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Two-Factor Authentication</CardTitle>
              <CardDescription>Add an extra layer of security to your account</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Authenticator App</p>
                  <p className="text-xs text-muted-foreground">Use Google Authenticator or similar</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="warning">Not configured</Badge>
                  <Button variant="outline" size="sm">Setup 2FA</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Active Sessions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { device: 'MacBook Pro 16"', location: 'San Francisco, CA', time: 'Current session', current: true },
                { device: 'iPhone 15 Pro', location: 'San Francisco, CA', time: '2 hours ago', current: false },
                { device: 'Chrome — Windows', location: 'New York, NY', time: '3 days ago', current: false },
              ].map(session => (
                <div key={session.device} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{session.device}</p>
                      {session.current && <Badge variant="success" className="text-[10px]">Current</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground">{session.location} · {session.time}</p>
                  </div>
                  {!session.current && <Button variant="ghost" size="sm" className="text-destructive">Revoke</Button>}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'appearance' && (
        <div className="space-y-4 max-w-2xl">
          <Card>
            <CardHeader>
              <CardTitle>Theme</CardTitle>
              <CardDescription>Choose your preferred color scheme</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-3">
                {['Dark', 'Light', 'System'].map(theme => (
                  <button
                    key={theme}
                    className={`p-4 rounded-xl border-2 transition-all text-center text-sm font-medium
                      ${theme === 'Dark' ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/50'}`}
                  >
                    <div className={`h-12 rounded-lg mb-2 ${
                      theme === 'Dark' ? 'bg-zinc-900' :
                      theme === 'Light' ? 'bg-zinc-100' :
                      'bg-gradient-to-br from-zinc-900 to-zinc-100'
                    }`} />
                    {theme}
                    {theme === 'Dark' && <Badge variant="success" className="ml-2 text-[10px]">Active</Badge>}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Density</CardTitle>
              <CardDescription>Control the spacing and density of the interface</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-3">
                {['Compact', 'Default', 'Comfortable'].map(density => (
                  <button
                    key={density}
                    className={`p-3 rounded-xl border-2 transition-all text-center text-sm
                      ${density === 'Default' ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/50 text-muted-foreground'}`}
                  >
                    {density}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </DashboardLayout>
  )
}
