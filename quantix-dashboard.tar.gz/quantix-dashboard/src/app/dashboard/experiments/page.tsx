'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, Badge, StatusBadge, SectionHeader, Button,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
  Input, Chip, Tabs
} from '@/components/ui'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, BarChart, Bar,
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell
} from 'recharts'
import { experiments, hyperparamComparison } from '@/lib/data'
import { FlaskConical, Trophy, Plus, Search, Filter, Download } from 'lucide-react'
import { cn } from '@/lib/utils'

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-xs">
      <p className="font-medium text-muted-foreground mb-1">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-mono">{typeof p.value === 'number' ? p.value.toFixed(2) : p.value}</span>
        </div>
      ))}
    </div>
  )
}

const RANK_COLORS = ['#f59e0b', '#94a3b8', '#cd7f32', '#8b5cf6', '#06b6d4']

const radarData = [
  { metric: 'Accuracy', exp47: 94.7, exp46: 93.9, exp45: 91.3 },
  { metric: 'F1 Score', exp47: 92.5, exp46: 91.8, exp45: 89.8 },
  { metric: 'Speed', exp47: 75, exp46: 80, exp45: 90 },
  { metric: 'Stability', exp47: 88, exp46: 85, exp45: 92 },
  { metric: 'Efficiency', exp47: 72, exp46: 76, exp45: 88 },
]

export default function ExperimentsPage() {
  const [activeTab, setActiveTab] = useState('list')
  const [selected, setSelected] = useState<string[]>([])
  const [search, setSearch] = useState('')

  const filtered = experiments.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.model.toLowerCase().includes(search.toLowerCase())
  )

  const toggle = (id: string) => {
    setSelected(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id].slice(0, 3))
  }

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'ML Platform' }, { label: 'Experiments' }]}>
      <SectionHeader
        title="Experiment Tracking"
        description="Manage, compare, and analyze ML experiments"
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm"><Download className="h-3.5 w-3.5" /> Export</Button>
            <Button size="sm"><Plus className="h-3.5 w-3.5" /> New Experiment</Button>
          </div>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Total Experiments" value={experiments.length} color="violet" icon={<FlaskConical className="h-5 w-5" />} />
        <MetricCard label="Best Accuracy" value="94.7%" change={1.8} color="emerald" icon={<Trophy className="h-5 w-5" />} />
        <MetricCard label="Completed" value={experiments.filter(e => e.status === 'completed').length} color="cyan" icon={<FlaskConical className="h-5 w-5" />} />
        <MetricCard label="Failed" value={experiments.filter(e => e.status === 'failed').length} color="rose" icon={<FlaskConical className="h-5 w-5" />} />
      </div>

      <Tabs
        tabs={[
          { id: 'list', label: 'All Experiments' },
          { id: 'leaderboard', label: 'Leaderboard' },
          { id: 'compare', label: 'Compare' },
        ]}
        active={activeTab}
        onChange={setActiveTab}
        className="mb-6"
      />

      {activeTab === 'list' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Input
              icon={<Search className="h-3.5 w-3.5" />}
              placeholder="Search experiments..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="max-w-xs"
            />
            <Button variant="outline" size="sm"><Filter className="h-3.5 w-3.5" /> Filter</Button>
            {selected.length > 0 && (
              <Button variant="outline" size="sm" onClick={() => setActiveTab('compare')}>
                Compare {selected.length} selected
              </Button>
            )}
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8"></TableHead>
                    <TableHead>Experiment</TableHead>
                    <TableHead>Model</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Accuracy</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Tags</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(exp => (
                    <TableRow key={exp.id} className={cn(selected.includes(exp.id) && 'bg-primary/5')}>
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={selected.includes(exp.id)}
                          onChange={() => toggle(exp.id)}
                          className="h-3.5 w-3.5 rounded border-border accent-primary cursor-pointer"
                        />
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium text-xs">{exp.name}</p>
                          <p className="font-mono text-[10px] text-muted-foreground">{exp.id}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{exp.model}</Badge>
                      </TableCell>
                      <TableCell><StatusBadge status={exp.status} /></TableCell>
                      <TableCell>
                        <span className={cn('font-mono font-semibold text-sm', exp.metric ? 'text-emerald-500' : 'text-muted-foreground')}>
                          {exp.metric ? `${exp.metric}%` : '—'}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-xs">{exp.duration}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {exp.tags.map(t => <Chip key={t} label={t} />)}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-xs">{exp.created}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">View</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'leaderboard' && (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>🏆 Experiment Leaderboard</CardTitle>
              <CardDescription>Ranked by best validation accuracy</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {experiments
                  .filter(e => e.rank !== null)
                  .sort((a, b) => (a.rank ?? 99) - (b.rank ?? 99))
                  .map(exp => (
                    <div key={exp.id} className={cn(
                      'flex items-center gap-4 p-4 rounded-xl border transition-all',
                      exp.rank === 1 ? 'border-amber-500/30 bg-amber-500/5' :
                      exp.rank === 2 ? 'border-zinc-400/30 bg-zinc-400/5' :
                      exp.rank === 3 ? 'border-orange-700/30 bg-orange-700/5' :
                      'border-border bg-secondary/20'
                    )}>
                      <div className="h-10 w-10 rounded-full flex items-center justify-center font-display text-lg font-bold flex-shrink-0"
                        style={{ background: `${RANK_COLORS[(exp.rank ?? 1) - 1]}20`, color: RANK_COLORS[(exp.rank ?? 1) - 1] }}>
                        {exp.rank === 1 ? '🥇' : exp.rank === 2 ? '🥈' : exp.rank === 3 ? '🥉' : exp.rank}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{exp.name}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <Badge variant="outline" className="text-[10px]">{exp.model}</Badge>
                          <span className="text-[10px] text-muted-foreground">{exp.duration} · {exp.created}</span>
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="font-display text-xl font-bold text-emerald-500">{exp.metric}%</p>
                        <p className="text-[10px] text-muted-foreground">Accuracy</p>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Performance Comparison</CardTitle>
              <CardDescription>Accuracy vs F1 score across completed experiments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={hyperparamComparison} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                    <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} domain={[80, 100]} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="accuracy" fill="#8b5cf6" radius={[4, 4, 0, 0]} name="Accuracy %" />
                    <Bar dataKey="f1" fill="#06b6d4" radius={[4, 4, 0, 0]} name="F1 %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'compare' && (
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Multi-Axis Performance Radar</CardTitle>
              <CardDescription>Comparing top 3 experiments across key metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="hsl(var(--border))" />
                    <PolarAngleAxis dataKey="metric" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                    <Radar name="exp-0047" dataKey="exp47" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.2} />
                    <Radar name="exp-0046" dataKey="exp46" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.2} />
                    <Radar name="exp-0045" dataKey="exp45" stroke="#10b981" fill="#10b981" fillOpacity={0.2} />
                    <Tooltip content={<CustomTooltip />} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center justify-center gap-6 text-xs text-muted-foreground mt-2">
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-violet-500" />exp-0047 (Best)</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-cyan-500" />exp-0046</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-500" />exp-0045</span>
              </div>
            </CardContent>
          </Card>

          {/* Hyperparameter table */}
          <Card>
            <CardHeader>
              <CardTitle>Hyperparameter Comparison</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Experiment</TableHead>
                    <TableHead>Accuracy</TableHead>
                    <TableHead>F1 Score</TableHead>
                    <TableHead>Loss</TableHead>
                    <TableHead>Learning Rate</TableHead>
                    <TableHead>Batch Size</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {hyperparamComparison.map((row, i) => (
                    <TableRow key={row.name}>
                      <TableCell className="font-mono font-medium text-primary">{row.name}</TableCell>
                      <TableCell className="font-mono text-emerald-500">{row.accuracy}%</TableCell>
                      <TableCell className="font-mono text-cyan-500">{row.f1}%</TableCell>
                      <TableCell className="font-mono">{row.loss}</TableCell>
                      <TableCell className="font-mono text-amber-500">{row.lr}</TableCell>
                      <TableCell className="font-mono">{row.batch}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}
    </DashboardLayout>
  )
}
