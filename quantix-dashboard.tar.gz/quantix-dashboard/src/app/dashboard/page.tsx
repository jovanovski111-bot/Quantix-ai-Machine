'use client'

import React from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  MetricCard, Card, CardHeader, CardTitle, CardContent, CardDescription,
  Badge, Avatar, Progress, StatusBadge, SectionHeader
} from '@/components/ui'
import {
  AreaChart, Area, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts'
import {
  kpis, performanceOverTime, recentActivity, modelVersions,
  predictionTimeline, gpuData, trainingRuns, experiments
} from '@/lib/data'
import { Brain, Database, Activity, Cpu, TrendingUp, FlaskConical, ArrowRight, Zap } from 'lucide-react'
import { cn, formatNumber, getStatusBg } from '@/lib/utils'

const KPI_ICONS = [Brain, TrendingUp, Activity, Cpu]
const KPI_COLORS: Array<'violet' | 'cyan' | 'emerald' | 'amber'> = ['violet', 'cyan', 'emerald', 'amber']

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-card border border-border rounded-xl p-3 shadow-xl text-xs">
      <p className="font-medium text-muted-foreground mb-2">{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground capitalize">{p.name}:</span>
          <span className="font-mono font-medium">{typeof p.value === 'number' ? p.value.toFixed(1) : p.value}</span>
        </div>
      ))}
    </div>
  )
}

export default function DashboardPage() {
  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'Dashboard' }]}>
      {/* Welcome banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600/20 via-primary/10 to-cyan-500/10 border border-violet-500/20 p-6 mb-6 animate-fade-in">
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="relative flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="status-dot-active animate-pulse-slow" />
              <span className="text-xs font-medium text-emerald-500">All systems operational</span>
            </div>
            <h1 className="font-display text-2xl font-bold text-foreground">Good morning, Elena 👋</h1>
            <p className="text-sm text-muted-foreground mt-1">
              You have 1 active training run and 3 unread alerts. QuantixBERT-L v2.4.1 is deployed in production.
            </p>
          </div>
          <div className="hidden md:flex items-center gap-3">
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Today's predictions</p>
              <p className="font-display text-2xl font-bold text-cyan-500">48.3K</p>
            </div>
            <div className="h-12 w-px bg-border" />
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Success rate</p>
              <p className="font-display text-2xl font-bold text-emerald-500">97.3%</p>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {kpis.map((kpi, i) => {
          const Icon = KPI_ICONS[i]
          return (
            <MetricCard
              key={kpi.label}
              label={kpi.label}
              value={kpi.value}
              change={kpi.change}
              changeLabel={kpi.changeLabel}
              color={KPI_COLORS[i]}
              icon={<Icon className="h-5 w-5" />}
              className={`stagger-${i + 1} opacity-0`}
            />
          )
        })}
      </div>

      {/* Main charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-4">
        {/* Model accuracy over time */}
        <Card className="xl:col-span-2 animate-fade-in stagger-2 opacity-0">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Model Performance History</CardTitle>
                <CardDescription>Accuracy & loss across training epochs</CardDescription>
              </div>
              <Badge variant="success" className="text-xs">Live</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceOverTime} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="gradAcc" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradVal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                  <XAxis dataKey="epoch" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} domain={[60, 100]} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="accuracy" stroke="#8b5cf6" strokeWidth={2} fill="url(#gradAcc)" name="Train Acc" />
                  <Area type="monotone" dataKey="valAccuracy" stroke="#06b6d4" strokeWidth={2} fill="url(#gradVal)" name="Val Acc" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Active training */}
        <Card className="animate-fade-in stagger-3 opacity-0">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Active Training</CardTitle>
              <div className="status-dot-active animate-pulse-slow" />
            </div>
            <CardDescription>Current runs</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {trainingRuns.slice(0, 3).map(run => (
              <div key={run.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="min-w-0">
                    <p className="text-xs font-medium truncate">{run.model}</p>
                    <p className="text-[10px] text-muted-foreground font-mono">{run.id}</p>
                  </div>
                  <StatusBadge status={run.status} />
                </div>
                <Progress
                  value={run.progress}
                  color={run.status === 'running' ? 'cyan' : run.status === 'completed' ? 'emerald' : 'rose'}
                  size="sm"
                />
                <div className="flex justify-between text-[10px] text-muted-foreground">
                  <span>Epoch {run.epoch}/{run.totalEpochs}</span>
                  <span className="font-mono">{run.progress}%</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Second row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 mb-4">
        {/* Prediction volume */}
        <Card className="xl:col-span-2 animate-fade-in stagger-3 opacity-0">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Prediction Volume (24h)</CardTitle>
                <CardDescription>Hourly prediction requests</CardDescription>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="h-2 w-2 rounded-full bg-violet-500" />
                Predictions
                <span className="h-2 w-2 rounded-full bg-rose-500 ml-2" />
                Errors
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={predictionTimeline.slice(0, 12)} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" strokeOpacity={0.5} />
                  <XAxis dataKey="hour" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickLine={false} axisLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="predictions" fill="#8b5cf6" radius={[3, 3, 0, 0]} name="predictions" />
                  <Bar dataKey="errors" fill="#f43f5e" radius={[3, 3, 0, 0]} name="errors" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* GPU quick status */}
        <Card className="animate-fade-in stagger-4 opacity-0">
          <CardHeader>
            <CardTitle>GPU Status</CardTitle>
            <CardDescription>Infrastructure health</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {gpuData.slice(0, 4).map(gpu => (
              <div key={gpu.name} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className={cn(
                      'h-1.5 w-1.5 rounded-full flex-shrink-0',
                      gpu.status === 'active' ? 'bg-emerald-500' : gpu.status === 'idle' ? 'bg-amber-500' : 'bg-muted-foreground'
                    )} />
                    <span className="font-mono truncate text-[10px]">{gpu.name}</span>
                  </div>
                  <span className="font-mono font-medium flex-shrink-0">{gpu.utilization}%</span>
                </div>
                <Progress
                  value={gpu.utilization}
                  color={gpu.utilization > 90 ? 'rose' : gpu.utilization > 70 ? 'amber' : 'emerald'}
                  size="sm"
                />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Recent activity */}
        <Card className="animate-fade-in stagger-4 opacity-0">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Activity</CardTitle>
              <button className="text-xs text-primary hover:underline flex items-center gap-1">
                View all <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentActivity.map(activity => (
                <div key={activity.id} className="flex items-start gap-3">
                  <Avatar initials={activity.avatar} size="sm" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs">
                      <span className="font-medium">{activity.user}</span>
                      <span className="text-muted-foreground"> {activity.action} </span>
                      <span className="font-medium text-primary">{activity.target}</span>
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Model versions */}
        <Card className="animate-fade-in stagger-5 opacity-0">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Model Registry</CardTitle>
              <a href="/dashboard/models" className="text-xs text-primary hover:underline flex items-center gap-1">
                View all <ArrowRight className="h-3 w-3" />
              </a>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {modelVersions.map(model => (
                <div key={model.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/40 transition-colors">
                  <div className="h-8 w-8 rounded-lg bg-violet-500/10 flex items-center justify-center flex-shrink-0">
                    <Brain className="h-4 w-4 text-violet-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-xs font-semibold font-mono">{model.id}</p>
                      <StatusBadge status={model.status} />
                    </div>
                    <p className="text-[10px] text-muted-foreground">{model.type} · {model.size}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs font-mono font-semibold text-emerald-500">{model.accuracy}%</p>
                    <p className="text-[10px] text-muted-foreground">{model.created}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
