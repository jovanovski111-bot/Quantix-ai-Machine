'use client'

import React from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent, CardDescription,
  MetricCard, SectionHeader, Button, Badge, StatusBadge,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Progress
} from '@/components/ui'
import { billingData, billingHistory } from '@/lib/data'
import { CreditCard, Download, Zap, TrendingUp, HardDrive, Activity } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function BillingPage() {
  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'Account' }, { label: 'Billing' }]}>
      <SectionHeader
        title="Billing & Subscription"
        description="Manage your plan, usage, and invoices"
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm"><Download className="h-3.5 w-3.5" /> Download Invoice</Button>
            <Button size="sm" variant="gradient">Upgrade Plan</Button>
          </div>
        }
      />

      {/* Current plan */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600/20 via-primary/10 to-cyan-500/10 border border-violet-500/20 p-6 mb-6">
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="relative flex items-start justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="success">Active</Badge>
              <span className="text-xs text-muted-foreground">Renews {billingData.nextBilling}</span>
            </div>
            <h2 className="font-display text-2xl font-bold">{billingData.plan} Plan</h2>
            <p className="text-muted-foreground mt-1 text-sm">
              Full access to all Quantix ML features, priority GPU allocation, and dedicated support.
            </p>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="font-display text-4xl font-bold text-violet-500">${billingData.amount}</p>
            <p className="text-sm text-muted-foreground">per month</p>
            <Button variant="outline" size="sm" className="mt-3">Change Plan</Button>
          </div>
        </div>
      </div>

      {/* Usage meters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {[
          {
            label: 'Predictions', icon: <TrendingUp className="h-4 w-4" />,
            used: '2.85M', limit: '5M',
            pct: billingData.usage.predictions.percentage,
            color: 'violet' as const,
          },
          {
            label: 'Training Hours', icon: <Activity className="h-4 w-4" />,
            used: '847h', limit: '1000h',
            pct: billingData.usage.training.percentage,
            color: billingData.usage.training.percentage > 80 ? 'rose' as const : 'cyan' as const,
          },
          {
            label: 'Storage', icon: <HardDrive className="h-4 w-4" />,
            used: '284.7 GB', limit: '500 GB',
            pct: billingData.usage.storage.percentage,
            color: 'emerald' as const,
          },
          {
            label: 'API Calls', icon: <Zap className="h-4 w-4" />,
            used: '3.89M', limit: '10M',
            pct: billingData.usage.apiCalls.percentage,
            color: 'amber' as const,
          },
        ].map(u => (
          <Card key={u.label} className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className={cn('h-8 w-8 rounded-lg flex items-center justify-center',
                  u.color === 'violet' ? 'bg-violet-500/10 text-violet-500' :
                  u.color === 'cyan' ? 'bg-cyan-500/10 text-cyan-500' :
                  u.color === 'emerald' ? 'bg-emerald-500/10 text-emerald-500' :
                  u.color === 'rose' ? 'bg-rose-500/10 text-rose-500' :
                  'bg-amber-500/10 text-amber-500'
                )}>
                  {u.icon}
                </div>
                <span className="font-medium text-sm">{u.label}</span>
              </div>
              <Badge variant={u.pct > 85 ? 'warning' : 'outline'}>
                {u.pct.toFixed(1)}% used
              </Badge>
            </div>
            <Progress value={u.pct} color={u.color} size="md" className="mb-2" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span className="font-mono">{u.used}</span>
              <span className="font-mono">of {u.limit}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Billing history */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice History</CardTitle>
          <CardDescription>All billing periods and payment status</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice</TableHead>
                <TableHead>Period</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {billingHistory.map(inv => (
                <TableRow key={inv.id}>
                  <TableCell className="font-mono text-primary text-xs">{inv.id}</TableCell>
                  <TableCell className="font-medium text-sm">{inv.period}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">{inv.date}</TableCell>
                  <TableCell className="font-mono font-semibold">${inv.amount.toLocaleString()}</TableCell>
                  <TableCell><StatusBadge status={inv.status} /></TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm"><Download className="h-3.5 w-3.5" /> PDF</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
