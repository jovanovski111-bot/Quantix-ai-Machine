'use client'

import React, { useState } from 'react'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import {
  Card, CardHeader, CardTitle, CardContent,
  MetricCard, Badge, StatusBadge, SectionHeader, Button,
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
  Input, Avatar
} from '@/components/ui'
import { users } from '@/lib/data'
import { Users, UserPlus, Search, Shield, Mail, MoreHorizontal, Edit, Trash2 } from 'lucide-react'
import { cn } from '@/lib/utils'

const ROLE_COLORS: Record<string, string> = {
  Admin: 'bg-violet-500/10 text-violet-500',
  'ML Engineer': 'bg-cyan-500/10 text-cyan-500',
  'Data Scientist': 'bg-emerald-500/10 text-emerald-500',
  Researcher: 'bg-amber-500/10 text-amber-500',
  'Data Engineer': 'bg-rose-500/10 text-rose-500',
}

export default function UsersPage() {
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')

  const filtered = users.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase())
    const matchRole = roleFilter === 'all' || u.role === roleFilter
    return matchSearch && matchRole
  })

  const roles = Array.from(new Set(users.map(u => u.role)))

  return (
    <DashboardLayout breadcrumb={[{ label: 'Quantix' }, { label: 'Management' }, { label: 'Users' }]}>
      <SectionHeader
        title="User Management"
        description="Manage team members, roles, and access"
        action={
          <Button size="sm"><UserPlus className="h-3.5 w-3.5" /> Invite User</Button>
        }
      />

      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Total Users" value={users.length} color="violet" icon={<Users className="h-5 w-5" />} />
        <MetricCard label="Active" value={users.filter(u => u.status === 'active').length} color="emerald" icon={<Users className="h-5 w-5" />} />
        <MetricCard label="Admins" value={users.filter(u => u.role === 'Admin').length} color="cyan" icon={<Shield className="h-5 w-5" />} />
        <MetricCard label="Teams" value="4" color="amber" icon={<Users className="h-5 w-5" />} />
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3 flex-wrap">
            <Input
              icon={<Search className="h-3.5 w-3.5" />}
              placeholder="Search users..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="max-w-xs"
            />
            <div className="flex items-center gap-1.5">
              <Button
                variant={roleFilter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setRoleFilter('all')}
              >All</Button>
              {roles.map(role => (
                <Button
                  key={role}
                  variant={roleFilter === role ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setRoleFilter(role)}
                >{role}</Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Team</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Models</TableHead>
                <TableHead>Last Active</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(user => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar initials={user.avatar} size="md" />
                      <div>
                        <p className="text-sm font-medium">{user.name}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Mail className="h-2.5 w-2.5" />{user.email}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className={cn('text-xs font-medium px-2 py-0.5 rounded-full', ROLE_COLORS[user.role] ?? 'bg-muted text-muted-foreground')}>
                      {user.role}
                    </span>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{user.team}</TableCell>
                  <TableCell><StatusBadge status={user.status} /></TableCell>
                  <TableCell className="font-mono text-sm">{user.models}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{user.lastActive}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{user.joined}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Edit className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}
