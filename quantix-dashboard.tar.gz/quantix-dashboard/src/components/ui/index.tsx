'use client'

import React from 'react'
import { cn } from '@/lib/utils'

// ============================================================
// BADGE
// ============================================================
interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info' | 'outline'
}

export function Badge({ className, variant = 'default', children, ...props }: BadgeProps) {
  const variants = {
    default: 'bg-primary/10 text-primary',
    success: 'bg-emerald-500/10 text-emerald-500',
    warning: 'bg-amber-500/10 text-amber-500',
    error: 'bg-rose-500/10 text-rose-500',
    info: 'bg-cyan-500/10 text-cyan-500',
    outline: 'border border-border text-muted-foreground bg-transparent',
  }
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </span>
  )
}

// ============================================================
// BUTTON
// ============================================================
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'secondary' | 'outline' | 'ghost' | 'destructive' | 'gradient'
  size?: 'sm' | 'md' | 'lg' | 'icon'
  loading?: boolean
}

export function Button({
  className,
  variant = 'default',
  size = 'md',
  loading = false,
  children,
  disabled,
  ...props
}: ButtonProps) {
  const variants = {
    default: 'bg-primary text-primary-foreground hover:bg-primary/90',
    secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
    outline: 'border border-border bg-transparent hover:bg-secondary text-foreground',
    ghost: 'bg-transparent hover:bg-secondary text-foreground',
    destructive: 'bg-destructive text-destructive-foreground hover:bg-destructive/90',
    gradient: 'bg-gradient-to-r from-violet-600 to-cyan-500 text-white hover:opacity-90',
  }
  const sizes = {
    sm: 'h-8 px-3 text-xs gap-1.5',
    md: 'h-9 px-4 text-sm gap-2',
    lg: 'h-11 px-6 text-base gap-2.5',
    icon: 'h-9 w-9 p-0',
  }
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center rounded-lg font-medium transition-all duration-150',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        'disabled:opacity-50 disabled:pointer-events-none',
        variants[variant],
        sizes[size],
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading && (
        <svg className="h-3.5 w-3.5 animate-spin" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      )}
      {children}
    </button>
  )
}

// ============================================================
// CARD
// ============================================================
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  glass?: boolean
  gradient?: boolean
  glow?: 'violet' | 'cyan' | 'emerald' | 'none'
}

export function Card({ className, glass = false, gradient = false, glow = 'none', children, ...props }: CardProps) {
  const glows = {
    violet: 'hover:shadow-[0_0_30px_rgba(139,92,246,0.12)]',
    cyan: 'hover:shadow-[0_0_30px_rgba(6,182,212,0.12)]',
    emerald: 'hover:shadow-[0_0_30px_rgba(16,185,129,0.12)]',
    none: '',
  }
  return (
    <div
      className={cn(
        'rounded-xl border border-border bg-card text-card-foreground',
        'transition-all duration-300',
        glass && 'bg-card/60 backdrop-blur-xl',
        gradient && 'bg-gradient-to-br from-card to-secondary/20',
        glows[glow],
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

export function CardHeader({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('flex flex-col gap-1.5 p-5 pb-0', className)} {...props}>{children}</div>
}

export function CardTitle({ className, children, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h3 className={cn('font-display text-base font-semibold leading-none tracking-tight', className)} {...props}>{children}</h3>
}

export function CardDescription({ className, children, ...props }: React.HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn('text-sm text-muted-foreground', className)} {...props}>{children}</p>
}

export function CardContent({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('p-5', className)} {...props}>{children}</div>
}

export function CardFooter({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('flex items-center p-5 pt-0', className)} {...props}>{children}</div>
}

// ============================================================
// PROGRESS BAR
// ============================================================
interface ProgressProps {
  value: number
  max?: number
  className?: string
  color?: 'violet' | 'cyan' | 'emerald' | 'amber' | 'rose'
  showLabel?: boolean
  size?: 'sm' | 'md' | 'lg'
  animated?: boolean
}

export function Progress({
  value,
  max = 100,
  className,
  color = 'violet',
  showLabel = false,
  size = 'md',
  animated = false,
}: ProgressProps) {
  const pct = Math.min(100, (value / max) * 100)
  const colors = {
    violet: 'from-violet-600 to-violet-400',
    cyan: 'from-cyan-500 to-cyan-400',
    emerald: 'from-emerald-500 to-emerald-400',
    amber: 'from-amber-500 to-amber-400',
    rose: 'from-rose-500 to-rose-400',
  }
  const sizes = { sm: 'h-1', md: 'h-1.5', lg: 'h-2.5' }
  return (
    <div className={cn('w-full', className)}>
      {showLabel && (
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-xs text-muted-foreground">Progress</span>
          <span className="text-xs font-medium font-mono">{pct.toFixed(0)}%</span>
        </div>
      )}
      <div className={cn('w-full bg-secondary rounded-full overflow-hidden', sizes[size])}>
        <div
          className={cn('h-full rounded-full bg-gradient-to-r transition-all duration-700', colors[color], animated && 'shimmer')}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  )
}

// ============================================================
// INPUT
// ============================================================
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode
  suffix?: React.ReactNode
}

export function Input({ className, icon, suffix, ...props }: InputProps) {
  return (
    <div className="relative flex items-center">
      {icon && (
        <span className="absolute left-3 text-muted-foreground pointer-events-none">
          {icon}
        </span>
      )}
      <input
        className={cn(
          'flex h-9 w-full rounded-lg border border-input bg-secondary/50 px-3 py-2 text-sm',
          'placeholder:text-muted-foreground',
          'focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent',
          'transition-all duration-150',
          'disabled:opacity-50 disabled:cursor-not-allowed',
          icon && 'pl-9',
          suffix && 'pr-9',
          className
        )}
        {...props}
      />
      {suffix && (
        <span className="absolute right-3 text-muted-foreground pointer-events-none">
          {suffix}
        </span>
      )}
    </div>
  )
}

// ============================================================
// SELECT
// ============================================================
interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  options: { value: string; label: string }[]
}

export function Select({ className, options, ...props }: SelectProps) {
  return (
    <select
      className={cn(
        'flex h-9 rounded-lg border border-input bg-secondary/50 px-3 py-2 text-sm',
        'focus:outline-none focus:ring-2 focus:ring-ring',
        'transition-all duration-150',
        'cursor-pointer',
        className
      )}
      {...props}
    >
      {options.map(opt => (
        <option key={opt.value} value={opt.value}>{opt.label}</option>
      ))}
    </select>
  )
}

// ============================================================
// AVATAR
// ============================================================
interface AvatarProps {
  initials: string
  size?: 'sm' | 'md' | 'lg'
  color?: 'violet' | 'cyan' | 'emerald' | 'amber' | 'rose' | 'auto'
  className?: string
}

const AVATAR_COLORS = [
  'from-violet-600 to-purple-600',
  'from-cyan-600 to-blue-600',
  'from-emerald-600 to-teal-600',
  'from-amber-600 to-orange-600',
  'from-rose-600 to-pink-600',
]

function getAvatarColor(initials: string): string {
  let hash = 0
  for (let i = 0; i < initials.length; i++) hash = initials.charCodeAt(i) + ((hash << 5) - hash)
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length]
}

export function Avatar({ initials, size = 'md', className }: AvatarProps) {
  const sizes = { sm: 'h-7 w-7 text-xs', md: 'h-8 w-8 text-xs', lg: 'h-10 w-10 text-sm' }
  return (
    <div className={cn(
      'rounded-full bg-gradient-to-br flex items-center justify-center font-semibold text-white flex-shrink-0',
      sizes[size],
      getAvatarColor(initials),
      className
    )}>
      {initials}
    </div>
  )
}

// ============================================================
// SPINNER
// ============================================================
export function Spinner({ className, size = 'md' }: { className?: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'h-3 w-3', md: 'h-4 w-4', lg: 'h-6 w-6' }
  return (
    <svg className={cn('animate-spin text-primary', sizes[size], className)} viewBox="0 0 24 24" fill="none">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
    </svg>
  )
}

// ============================================================
// SEPARATOR
// ============================================================
export function Separator({ className, orientation = 'horizontal' }: { className?: string; orientation?: 'horizontal' | 'vertical' }) {
  return (
    <div className={cn(
      'bg-border flex-shrink-0',
      orientation === 'horizontal' ? 'h-px w-full' : 'h-full w-px',
      className
    )} />
  )
}

// ============================================================
// TOOLTIP (simple hover)
// ============================================================
export function Tooltip({ children, content, className }: { children: React.ReactNode; content: string; className?: string }) {
  return (
    <div className={cn('group relative inline-flex', className)}>
      {children}
      <div className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-150 z-50">
        <div className="rounded-md bg-foreground/90 text-background text-xs py-1 px-2 whitespace-nowrap">
          {content}
        </div>
      </div>
    </div>
  )
}

// ============================================================
// TABS
// ============================================================
interface TabsProps {
  tabs: { id: string; label: string; icon?: React.ReactNode }[]
  active: string
  onChange: (id: string) => void
  className?: string
}

export function Tabs({ tabs, active, onChange, className }: TabsProps) {
  return (
    <div className={cn('flex items-center gap-1 p-1 bg-secondary/60 rounded-lg', className)}>
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={cn(
            'flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-150',
            active === tab.id
              ? 'bg-background text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          )}
        >
          {tab.icon}
          {tab.label}
        </button>
      ))}
    </div>
  )
}

// ============================================================
// TABLE
// ============================================================
export function Table({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className="w-full overflow-auto">
      <table className={cn('w-full caption-bottom text-sm', className)}>{children}</table>
    </div>
  )
}

export function TableHeader({ children }: { children: React.ReactNode }) {
  return <thead>{children}</thead>
}

export function TableBody({ children }: { children: React.ReactNode }) {
  return <tbody>{children}</tbody>
}

export function TableRow({ className, children, ...props }: React.HTMLAttributes<HTMLTableRowElement>) {
  return (
    <tr className={cn('border-b border-border/50 transition-colors hover:bg-muted/30', className)} {...props}>
      {children}
    </tr>
  )
}

export function TableHead({ className, children, ...props }: React.ThHTMLAttributes<HTMLTableCellElement>) {
  return (
    <th className={cn('h-10 px-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wide', className)} {...props}>
      {children}
    </th>
  )
}

export function TableCell({ className, children, ...props }: React.TdHTMLAttributes<HTMLTableCellElement>) {
  return (
    <td className={cn('px-4 py-3 text-sm', className)} {...props}>
      {children}
    </td>
  )
}

// ============================================================
// METRIC CARD
// ============================================================
interface MetricCardProps {
  label: string
  value: string | number
  change?: number
  changeLabel?: string
  icon?: React.ReactNode
  color?: 'violet' | 'cyan' | 'emerald' | 'amber' | 'rose'
  className?: string
  suffix?: string
}

const METRIC_COLORS = {
  violet: { bg: 'bg-violet-500/10', text: 'text-violet-500', icon: 'text-violet-500' },
  cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-500', icon: 'text-cyan-500' },
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-500', icon: 'text-emerald-500' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-500', icon: 'text-amber-500' },
  rose: { bg: 'bg-rose-500/10', text: 'text-rose-500', icon: 'text-rose-500' },
}

export function MetricCard({ label, value, change, changeLabel, icon, color = 'violet', className, suffix }: MetricCardProps) {
  const c = METRIC_COLORS[color]
  const isPositive = change !== undefined && change > 0
  const isNeutral = change === undefined

  return (
    <Card className={cn('p-5 animate-fade-in', className)} glow={color === 'violet' ? 'violet' : color === 'cyan' ? 'cyan' : color === 'emerald' ? 'emerald' : 'none'}>
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-3">{label}</p>
          <div className="flex items-baseline gap-1">
            <p className={cn('text-2xl font-display font-bold', c.text)}>{value}</p>
            {suffix && <span className="text-sm text-muted-foreground">{suffix}</span>}
          </div>
          {!isNeutral && (
            <div className="flex items-center gap-1 mt-2">
              <span className={isPositive ? 'metric-up' : 'metric-down'}>
                {isPositive ? '↑' : '↓'} {Math.abs(change!).toFixed(1)}%
              </span>
              {changeLabel && <span className="text-xs text-muted-foreground">{changeLabel}</span>}
            </div>
          )}
        </div>
        {icon && (
          <div className={cn('rounded-xl p-2.5 flex-shrink-0', c.bg)}>
            <span className={c.icon}>{icon}</span>
          </div>
        )}
      </div>
    </Card>
  )
}

// ============================================================
// STATUS BADGE  
// ============================================================
import { getStatusBg } from '@/lib/utils'

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium capitalize', getStatusBg(status))}>
      <span className={cn('h-1.5 w-1.5 rounded-full bg-current')} />
      {status}
    </span>
  )
}

// ============================================================
// EMPTY STATE
// ============================================================
export function EmptyState({ icon, title, description, action }: { icon: React.ReactNode; title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="rounded-2xl bg-secondary/60 p-4 mb-4 text-muted-foreground">{icon}</div>
      <h3 className="font-display font-semibold text-foreground mb-1">{title}</h3>
      {description && <p className="text-sm text-muted-foreground max-w-sm mb-4">{description}</p>}
      {action}
    </div>
  )
}

// ============================================================
// SECTION HEADER
// ============================================================
export function SectionHeader({ title, description, action, className }: { title: string; description?: string; action?: React.ReactNode; className?: string }) {
  return (
    <div className={cn('flex items-start justify-between gap-4 mb-6', className)}>
      <div>
        <h2 className="font-display text-xl font-semibold text-foreground">{title}</h2>
        {description && <p className="text-sm text-muted-foreground mt-0.5">{description}</p>}
      </div>
      {action}
    </div>
  )
}

// ============================================================
// SKELETON LOADER
// ============================================================
export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={cn('animate-pulse rounded-md bg-secondary', className)} />
  )
}

// ============================================================
// ALERT
// ============================================================
interface AlertProps {
  type?: 'info' | 'success' | 'warning' | 'error'
  title?: string
  children: React.ReactNode
  className?: string
}

export function Alert({ type = 'info', title, children, className }: AlertProps) {
  const styles = {
    info: 'bg-cyan-500/10 border-cyan-500/20 text-cyan-700 dark:text-cyan-400',
    success: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-700 dark:text-emerald-400',
    warning: 'bg-amber-500/10 border-amber-500/20 text-amber-700 dark:text-amber-400',
    error: 'bg-rose-500/10 border-rose-500/20 text-rose-700 dark:text-rose-400',
  }
  return (
    <div className={cn('rounded-lg border p-4', styles[type], className)}>
      {title && <p className="font-medium text-sm mb-1">{title}</p>}
      <p className="text-sm opacity-90">{children}</p>
    </div>
  )
}

// ============================================================
// COPY BUTTON
// ============================================================
export function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = React.useState(false)
  const copy = () => {
    navigator.clipboard.writeText(text).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={copy} className="text-muted-foreground hover:text-foreground transition-colors text-xs">
      {copied ? '✓ Copied' : 'Copy'}
    </button>
  )
}

// ============================================================
// TOGGLE SWITCH
// ============================================================
export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <label className="flex items-center gap-2 cursor-pointer">
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative h-5 w-9 rounded-full transition-colors duration-200',
          checked ? 'bg-primary' : 'bg-secondary'
        )}
      >
        <span className={cn(
          'absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform duration-200',
          checked ? 'translate-x-4' : 'translate-x-0'
        )} />
      </button>
      {label && <span className="text-sm text-muted-foreground">{label}</span>}
    </label>
  )
}

// ============================================================
// CHIP / TAG
// ============================================================
export function Chip({ label, onRemove, color = 'default' }: { label: string; onRemove?: () => void; color?: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-secondary border border-border px-2.5 py-0.5 text-xs font-medium">
      {label}
      {onRemove && (
        <button onClick={onRemove} className="ml-0.5 hover:text-destructive transition-colors">×</button>
      )}
    </span>
  )
}
