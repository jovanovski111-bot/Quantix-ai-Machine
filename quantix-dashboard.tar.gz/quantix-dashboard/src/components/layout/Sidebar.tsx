'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, Brain, Database, Activity, TrendingUp,
  Cpu, FlaskConical, Users, Key, ScrollText, Bell,
  CreditCard, Settings, ChevronRight, Zap, ChevronDown,
} from 'lucide-react'
import { Badge } from '@/components/ui'

interface NavItem {
  label: string
  href?: string
  icon: React.ReactNode
  badge?: string | number
  badgeVariant?: 'default' | 'success' | 'warning' | 'error' | 'info'
  children?: NavItem[]
}

const NAV_SECTIONS: { title: string; items: NavItem[] }[] = [
  {
    title: 'Overview',
    items: [
      {
        label: 'Dashboard',
        href: '/dashboard',
        icon: <LayoutDashboard className="h-4 w-4" />,
      },
    ],
  },
  {
    title: 'ML Platform',
    items: [
      {
        label: 'Model Analytics',
        href: '/dashboard/models',
        icon: <Brain className="h-4 w-4" />,
        badge: '12',
        badgeVariant: 'info',
      },
      {
        label: 'Datasets',
        href: '/dashboard/datasets',
        icon: <Database className="h-4 w-4" />,
        badge: '5',
        badgeVariant: 'default',
      },
      {
        label: 'Training',
        href: '/dashboard/training',
        icon: <Activity className="h-4 w-4" />,
        badge: '1',
        badgeVariant: 'success',
      },
      {
        label: 'Predictions',
        href: '/dashboard/predictions',
        icon: <TrendingUp className="h-4 w-4" />,
      },
      {
        label: 'GPU Monitor',
        href: '/dashboard/gpu',
        icon: <Cpu className="h-4 w-4" />,
        badge: '!',
        badgeVariant: 'warning',
      },
      {
        label: 'Experiments',
        href: '/dashboard/experiments',
        icon: <FlaskConical className="h-4 w-4" />,
      },
    ],
  },
  {
    title: 'Management',
    items: [
      {
        label: 'Users',
        href: '/dashboard/users',
        icon: <Users className="h-4 w-4" />,
      },
      {
        label: 'API Keys',
        href: '/dashboard/api-keys',
        icon: <Key className="h-4 w-4" />,
      },
      {
        label: 'System Logs',
        href: '/dashboard/logs',
        icon: <ScrollText className="h-4 w-4" />,
      },
      {
        label: 'Notifications',
        href: '/dashboard/notifications',
        icon: <Bell className="h-4 w-4" />,
        badge: '3',
        badgeVariant: 'error',
      },
    ],
  },
  {
    title: 'Account',
    items: [
      {
        label: 'Billing',
        href: '/dashboard/billing',
        icon: <CreditCard className="h-4 w-4" />,
      },
      {
        label: 'Settings',
        href: '/dashboard/settings',
        icon: <Settings className="h-4 w-4" />,
      },
    ],
  },
]

interface SidebarProps {
  collapsed?: boolean
  onToggle?: () => void
}

export function Sidebar({ collapsed = false, onToggle }: SidebarProps) {
  const pathname = usePathname()
  const [expandedSections, setExpandedSections] = useState<string[]>(['Overview', 'ML Platform', 'Management', 'Account'])

  const toggleSection = (title: string) => {
    setExpandedSections(prev =>
      prev.includes(title) ? prev.filter(s => s !== title) : [...prev, title]
    )
  }

  return (
    <aside
      className={cn(
        'fixed top-0 left-0 h-screen bg-card border-r border-border flex flex-col z-40',
        'transition-all duration-300',
        collapsed ? 'w-16' : 'w-[260px]'
      )}
    >
      {/* Logo */}
      <div className={cn(
        'flex items-center h-16 px-4 border-b border-border flex-shrink-0',
        collapsed ? 'justify-center' : 'gap-2.5'
      )}>
        <div className="relative flex-shrink-0">
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <div className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-500 border-2 border-card" />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <p className="font-display text-sm font-bold text-foreground leading-none">Quantix</p>
            <p className="text-[10px] text-muted-foreground font-mono mt-0.5">ML Platform v2.4</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-2">
        {NAV_SECTIONS.map(section => (
          <div key={section.title} className="mb-4">
            {!collapsed && (
              <button
                onClick={() => toggleSection(section.title)}
                className="flex items-center justify-between w-full px-2 mb-1.5"
              >
                <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/60">
                  {section.title}
                </span>
                <ChevronDown
                  className={cn(
                    'h-3 w-3 text-muted-foreground/50 transition-transform',
                    expandedSections.includes(section.title) ? 'rotate-0' : '-rotate-90'
                  )}
                />
              </button>
            )}

            {(expandedSections.includes(section.title) || collapsed) && (
              <div className="space-y-0.5">
                {section.items.map(item => {
                  const isActive = item.href === pathname || (item.href !== '/dashboard' && pathname.startsWith(item.href ?? ''))
                  return (
                    <Link key={item.label} href={item.href ?? '#'}>
                      <div
                        className={cn(
                          'flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-all duration-150 group relative',
                          collapsed ? 'justify-center px-0' : '',
                          isActive
                            ? 'bg-primary/10 text-primary'
                            : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                        )}
                      >
                        {isActive && !collapsed && (
                          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-primary rounded-full" />
                        )}
                        <span className={cn('flex-shrink-0 transition-transform group-hover:scale-105', isActive ? 'text-primary' : '')}>
                          {item.icon}
                        </span>
                        {!collapsed && (
                          <>
                            <span className="flex-1 min-w-0 truncate">{item.label}</span>
                            {item.badge && (
                              <Badge variant={item.badgeVariant ?? 'default'} className="text-[10px] px-1.5 py-0 h-4">
                                {item.badge}
                              </Badge>
                            )}
                          </>
                        )}
                        {collapsed && item.badge && (
                          <span className="absolute top-0.5 right-0.5 h-2 w-2 rounded-full bg-rose-500" />
                        )}
                      </div>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>
        ))}
      </nav>

      {/* User profile at bottom */}
      {!collapsed && (
        <div className="p-3 border-t border-border flex-shrink-0">
          <div className="flex items-center gap-2.5 rounded-lg p-2 hover:bg-secondary cursor-pointer transition-colors">
            <div className="h-7 w-7 rounded-full bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center text-white text-xs font-semibold flex-shrink-0">
              EV
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">Elena Vasquez</p>
              <p className="text-[10px] text-muted-foreground truncate">Admin · Enterprise</p>
            </div>
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
          </div>
        </div>
      )}

      {/* Collapse toggle */}
      <button
        onClick={onToggle}
        className={cn(
          'absolute -right-3 top-20 h-6 w-6 rounded-full bg-card border border-border shadow-sm',
          'flex items-center justify-center hover:bg-secondary transition-colors z-10'
        )}
      >
        <ChevronRight className={cn('h-3 w-3 text-muted-foreground transition-transform', collapsed ? '' : 'rotate-180')} />
      </button>
    </aside>
  )
}
