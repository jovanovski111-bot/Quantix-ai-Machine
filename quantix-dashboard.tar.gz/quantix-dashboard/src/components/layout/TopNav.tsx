'use client'

import React, { useState, useEffect } from 'react'
import { cn } from '@/lib/utils'
import { Search, Bell, Moon, Sun, Command, X } from 'lucide-react'
import { Badge, Avatar } from '@/components/ui'
import { notifications } from '@/lib/data'

interface TopNavProps {
  sidebarCollapsed: boolean
  title?: string
  breadcrumb?: { label: string; href?: string }[]
}

function useTheme() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')

  useEffect(() => {
    const stored = localStorage.getItem('quantix-theme') as 'dark' | 'light' | null
    const initial = stored ?? 'dark'
    setTheme(initial)
    document.documentElement.classList.toggle('dark', initial === 'dark')
  }, [])

  const toggle = () => {
    const next = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    localStorage.setItem('quantix-theme', next)
    document.documentElement.classList.toggle('dark', next === 'dark')
  }

  return { theme, toggle }
}

export function TopNav({ sidebarCollapsed, breadcrumb }: TopNavProps) {
  const { theme, toggle } = useTheme()
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [notifOpen, setNotifOpen] = useState(false)
  const unreadCount = notifications.filter(n => !n.read).length

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setSearchOpen(true)
      }
      if (e.key === 'Escape') { setSearchOpen(false); setNotifOpen(false) }
    }
    window.addEventListener('keydown', down)
    return () => window.removeEventListener('keydown', down)
  }, [])

  const SEARCH_RESULTS = [
    { label: 'QuantixBERT-L v2.4.1', type: 'Model', href: '/dashboard/models' },
    { label: 'SentimentCorpus-EN-2024', type: 'Dataset', href: '/dashboard/datasets' },
    { label: 'Run run-0091', type: 'Training', href: '/dashboard/training' },
    { label: 'Experiment exp-0047', type: 'Experiment', href: '/dashboard/experiments' },
    { label: 'GPU Monitor', type: 'Page', href: '/dashboard/gpu' },
  ].filter(r => !searchQuery || r.label.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <>
      <header
        className={cn(
          'fixed top-0 right-0 h-16 bg-card/80 backdrop-blur-xl border-b border-border z-30',
          'flex items-center gap-3 px-5',
          'transition-all duration-300',
          sidebarCollapsed ? 'left-16' : 'left-[260px]'
        )}
      >
        {/* Breadcrumb */}
        <div className="flex-1 min-w-0">
          {breadcrumb && (
            <div className="flex items-center gap-1.5 text-sm">
              {breadcrumb.map((crumb, i) => (
                <React.Fragment key={crumb.label}>
                  {i > 0 && <span className="text-muted-foreground/40">/</span>}
                  <span className={cn(
                    i === breadcrumb.length - 1
                      ? 'font-semibold text-foreground font-display'
                      : 'text-muted-foreground hover:text-foreground cursor-pointer'
                  )}>
                    {crumb.label}
                  </span>
                </React.Fragment>
              ))}
            </div>
          )}
        </div>

        {/* Search bar */}
        <button
          onClick={() => setSearchOpen(true)}
          className="hidden md:flex items-center gap-2 h-8 px-3 rounded-lg bg-secondary/60 border border-border/50 text-sm text-muted-foreground hover:bg-secondary transition-colors min-w-[180px]"
        >
          <Search className="h-3.5 w-3.5" />
          <span className="text-xs flex-1 text-left">Search...</span>
          <div className="flex items-center gap-0.5 text-[10px] font-mono bg-background/50 rounded px-1 py-0.5">
            <Command className="h-2.5 w-2.5" />K
          </div>
        </button>

        {/* Theme toggle */}
        <button
          onClick={toggle}
          className="h-8 w-8 rounded-lg border border-border/50 bg-secondary/60 hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-all"
          title="Toggle theme"
        >
          {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="h-8 w-8 rounded-lg border border-border/50 bg-secondary/60 hover:bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-all relative"
          >
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 h-3.5 w-3.5 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <div className="absolute right-0 top-10 w-80 bg-card border border-border rounded-xl shadow-xl z-50 overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b border-border">
                <h3 className="font-display font-semibold text-sm">Notifications</h3>
                <span className="text-xs text-muted-foreground">{unreadCount} unread</span>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.slice(0, 5).map(n => (
                  <div key={n.id} className={cn(
                    'flex gap-3 p-3.5 border-b border-border/50 hover:bg-secondary/40 transition-colors cursor-pointer',
                    !n.read && 'bg-primary/5'
                  )}>
                    <div className={cn(
                      'h-2 w-2 rounded-full mt-1.5 flex-shrink-0',
                      n.type === 'success' ? 'bg-emerald-500' :
                      n.type === 'warning' ? 'bg-amber-500' :
                      n.type === 'error' ? 'bg-rose-500' : 'bg-cyan-500'
                    )} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium">{n.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{n.message}</p>
                      <p className="text-[10px] text-muted-foreground/60 mt-1">{n.time}</p>
                    </div>
                    {!n.read && <div className="h-1.5 w-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />}
                  </div>
                ))}
              </div>
              <div className="p-3 border-t border-border">
                <button className="text-xs text-primary hover:underline w-full text-center">View all notifications</button>
              </div>
            </div>
          )}
        </div>

        {/* User avatar */}
        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center text-white text-xs font-semibold cursor-pointer hover:opacity-90 transition-opacity flex-shrink-0">
          EV
        </div>
      </header>

      {/* Search Modal */}
      {searchOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-start justify-center pt-24">
          <div className="w-full max-w-xl bg-card border border-border rounded-2xl shadow-2xl overflow-hidden animate-scale-in">
            <div className="flex items-center gap-3 p-4 border-b border-border">
              <Search className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <input
                autoFocus
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search models, datasets, experiments..."
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
              <button onClick={() => setSearchOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="p-2 max-h-80 overflow-y-auto">
              {SEARCH_RESULTS.length > 0 ? (
                SEARCH_RESULTS.map(result => (
                  <a key={result.label} href={result.href} onClick={() => setSearchOpen(false)}>
                    <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-secondary transition-colors cursor-pointer">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{result.label}</p>
                      </div>
                      <Badge variant="outline">{result.type}</Badge>
                    </div>
                  </a>
                ))
              ) : (
                <div className="py-8 text-center text-sm text-muted-foreground">No results found</div>
              )}
            </div>
            <div className="p-3 border-t border-border flex items-center gap-4 text-[11px] text-muted-foreground">
              <span><kbd className="font-mono bg-secondary px-1 rounded">↵</kbd> to select</span>
              <span><kbd className="font-mono bg-secondary px-1 rounded">↑↓</kbd> to navigate</span>
              <span><kbd className="font-mono bg-secondary px-1 rounded">Esc</kbd> to close</span>
            </div>
          </div>
        </div>
      )}

      {/* Backdrop for notifications */}
      {notifOpen && (
        <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
      )}
    </>
  )
}
