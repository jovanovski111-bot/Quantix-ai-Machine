'use client'

import React, { useState } from 'react'
import { cn } from '@/lib/utils'
import { Sidebar } from './Sidebar'
import { TopNav } from './TopNav'

interface DashboardLayoutProps {
  children: React.ReactNode
  breadcrumb?: { label: string; href?: string }[]
}

export function DashboardLayout({ children, breadcrumb }: DashboardLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  return (
    <div className="min-h-screen bg-background bg-grid">
      <Sidebar
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      <TopNav
        sidebarCollapsed={sidebarCollapsed}
        breadcrumb={breadcrumb}
      />
      <main
        className={cn(
          'min-h-screen pt-16 transition-all duration-300',
          sidebarCollapsed ? 'pl-16' : 'pl-[260px]'
        )}
      >
        <div className="p-6 max-w-[1600px]">
          {children}
        </div>
      </main>
    </div>
  )
}
