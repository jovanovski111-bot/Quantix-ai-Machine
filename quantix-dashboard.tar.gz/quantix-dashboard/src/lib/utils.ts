import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}

export function formatPercent(n: number, decimals = 1): string {
  return `${n.toFixed(decimals)}%`
}

export function formatBytes(gb: number): string {
  if (gb >= 1000) return `${(gb / 1000).toFixed(1)} TB`
  if (gb >= 1) return `${gb.toFixed(1)} GB`
  return `${(gb * 1000).toFixed(0)} MB`
}

export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    active: 'text-emerald-500',
    running: 'text-cyan-500',
    completed: 'text-emerald-500',
    failed: 'text-rose-500',
    error: 'text-rose-500',
    warning: 'text-amber-500',
    idle: 'text-muted-foreground',
    offline: 'text-muted-foreground',
    processing: 'text-cyan-500',
    ready: 'text-emerald-500',
    archived: 'text-muted-foreground',
    deprecated: 'text-rose-500',
    deployed: 'text-emerald-500',
    pending: 'text-amber-500',
    paid: 'text-emerald-500',
    revoked: 'text-rose-500',
    inactive: 'text-muted-foreground',
  }
  return map[status] ?? 'text-muted-foreground'
}

export function getStatusBg(status: string): string {
  const map: Record<string, string> = {
    active: 'bg-emerald-500/10 text-emerald-500',
    running: 'bg-cyan-500/10 text-cyan-500',
    completed: 'bg-emerald-500/10 text-emerald-500',
    failed: 'bg-rose-500/10 text-rose-500',
    error: 'bg-rose-500/10 text-rose-500',
    warning: 'bg-amber-500/10 text-amber-500',
    idle: 'bg-muted text-muted-foreground',
    offline: 'bg-muted text-muted-foreground',
    processing: 'bg-cyan-500/10 text-cyan-500',
    ready: 'bg-emerald-500/10 text-emerald-500',
    archived: 'bg-muted text-muted-foreground',
    deprecated: 'bg-rose-500/10 text-rose-500',
    deployed: 'bg-emerald-500/10 text-emerald-500',
    pending: 'bg-amber-500/10 text-amber-500',
    paid: 'bg-emerald-500/10 text-emerald-500',
    revoked: 'bg-rose-500/10 text-rose-500',
    inactive: 'bg-muted text-muted-foreground',
  }
  return map[status] ?? 'bg-muted text-muted-foreground'
}
