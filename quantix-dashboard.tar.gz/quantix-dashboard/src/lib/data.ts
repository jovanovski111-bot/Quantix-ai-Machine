// ============================================================
// QUANTIX DASHBOARD — MOCK DATA
// ============================================================

export const modelMetrics = {
  accuracy: 94.7,
  precision: 93.2,
  recall: 91.8,
  f1Score: 92.5,
  loss: 0.0842,
  auc: 0.978,
  trainingTime: '2h 34m',
  parameters: '175M',
}

export const performanceOverTime = [
  { epoch: 1, accuracy: 72.1, loss: 0.612, valAccuracy: 68.3, valLoss: 0.701 },
  { epoch: 5, accuracy: 81.4, loss: 0.431, valAccuracy: 78.2, valLoss: 0.489 },
  { epoch: 10, accuracy: 86.9, loss: 0.312, valAccuracy: 84.1, valLoss: 0.351 },
  { epoch: 15, accuracy: 89.7, loss: 0.241, valAccuracy: 87.3, valLoss: 0.278 },
  { epoch: 20, accuracy: 91.2, loss: 0.198, valAccuracy: 89.1, valLoss: 0.231 },
  { epoch: 25, accuracy: 92.8, loss: 0.162, valAccuracy: 91.0, valLoss: 0.192 },
  { epoch: 30, accuracy: 93.5, loss: 0.143, valAccuracy: 92.1, valLoss: 0.171 },
  { epoch: 35, accuracy: 94.1, loss: 0.128, valAccuracy: 92.8, valLoss: 0.156 },
  { epoch: 40, accuracy: 94.7, loss: 0.084, valAccuracy: 93.4, valLoss: 0.142 },
]

export const rocCurveData = [
  { fpr: 0, tpr: 0 },
  { fpr: 0.02, tpr: 0.38 },
  { fpr: 0.05, tpr: 0.61 },
  { fpr: 0.08, tpr: 0.74 },
  { fpr: 0.12, tpr: 0.82 },
  { fpr: 0.18, tpr: 0.88 },
  { fpr: 0.25, tpr: 0.91 },
  { fpr: 0.35, tpr: 0.94 },
  { fpr: 0.5, tpr: 0.96 },
  { fpr: 0.65, tpr: 0.97 },
  { fpr: 0.8, tpr: 0.98 },
  { fpr: 1, tpr: 1 },
]

export const confusionMatrix = [
  [892, 23, 8, 4],
  [31, 847, 15, 9],
  [12, 18, 906, 11],
  [6, 7, 13, 921],
]

export const confusionLabels = ['Positive', 'Negative', 'Neutral', 'Mixed']

export const modelVersions = [
  { id: 'v2.4.1', created: '2024-03-14', accuracy: 94.7, status: 'deployed', size: '1.2 GB', type: 'Transformer' },
  { id: 'v2.4.0', created: '2024-03-10', accuracy: 93.9, status: 'archived', size: '1.2 GB', type: 'Transformer' },
  { id: 'v2.3.5', created: '2024-03-02', accuracy: 92.1, status: 'archived', size: '890 MB', type: 'BERT' },
  { id: 'v2.3.0', created: '2024-02-22', accuracy: 90.4, status: 'archived', size: '890 MB', type: 'BERT' },
  { id: 'v2.2.8', created: '2024-02-14', accuracy: 88.7, status: 'deprecated', size: '750 MB', type: 'CNN' },
]

export const modelComparison = [
  { model: 'QuantixBERT-L', accuracy: 94.7, f1: 92.5, latency: 42, size: 1.2 },
  { model: 'QuantixGPT-M', accuracy: 91.3, f1: 89.8, latency: 28, size: 0.87 },
  { model: 'RoBERTa-Base', accuracy: 88.6, f1: 86.2, latency: 18, size: 0.49 },
  { model: 'DistilBERT', accuracy: 85.4, f1: 83.1, latency: 11, size: 0.26 },
  { model: 'FastText-XL', accuracy: 79.2, f1: 77.8, latency: 4, size: 0.09 },
]

// Dataset data
export const datasets = [
  {
    id: 'ds-001',
    name: 'SentimentCorpus-EN-2024',
    records: 847293,
    features: 64,
    size: '2.4 GB',
    type: 'NLP',
    status: 'ready',
    created: '2024-03-01',
    version: 'v3.1',
    tags: ['sentiment', 'english', 'twitter'],
    missingValues: 1.2,
  },
  {
    id: 'ds-002',
    name: 'ImageNet-Custom-10K',
    records: 10000,
    features: 224,
    size: '18.7 GB',
    type: 'Vision',
    status: 'processing',
    created: '2024-03-10',
    version: 'v1.0',
    tags: ['images', 'classification', 'custom'],
    missingValues: 0,
  },
  {
    id: 'ds-003',
    name: 'FinancialTimeSeries-Q1',
    records: 2100000,
    features: 28,
    size: '890 MB',
    type: 'Tabular',
    status: 'ready',
    created: '2024-02-28',
    version: 'v2.3',
    tags: ['finance', 'timeseries', 'stocks'],
    missingValues: 3.7,
  },
  {
    id: 'ds-004',
    name: 'MedicalRecords-Synthetic',
    records: 50000,
    features: 142,
    size: '340 MB',
    type: 'Tabular',
    status: 'ready',
    created: '2024-03-05',
    version: 'v1.2',
    tags: ['medical', 'synthetic', 'classification'],
    missingValues: 8.4,
  },
  {
    id: 'ds-005',
    name: 'VideoFrames-Action-Recognition',
    records: 25600,
    features: 512,
    size: '142 GB',
    type: 'Vision',
    status: 'error',
    created: '2024-03-12',
    version: 'v0.9',
    tags: ['video', 'action', 'recognition'],
    missingValues: 0,
  },
]

export const columnStats = [
  { name: 'text', type: 'string', unique: 847293, missing: 0, coverage: 100 },
  { name: 'sentiment', type: 'categorical', unique: 3, missing: 0.2, coverage: 99.8 },
  { name: 'confidence', type: 'float', unique: 847291, missing: 1.2, coverage: 98.8 },
  { name: 'language', type: 'categorical', unique: 47, missing: 0, coverage: 100 },
  { name: 'timestamp', type: 'datetime', unique: 312847, missing: 0, coverage: 100 },
  { name: 'source', type: 'categorical', unique: 12, missing: 4.1, coverage: 95.9 },
  { name: 'user_id', type: 'string', unique: 423847, missing: 2.3, coverage: 97.7 },
  { name: 'retweets', type: 'integer', unique: 48291, missing: 0, coverage: 100 },
]

export const classDistribution = [
  { label: 'Positive', count: 312847, percentage: 36.9 },
  { label: 'Negative', count: 284621, percentage: 33.6 },
  { label: 'Neutral', count: 249825, percentage: 29.5 },
]

// Training data
export const trainingRuns = [
  {
    id: 'run-0091',
    model: 'QuantixBERT-L',
    status: 'running',
    progress: 78,
    epoch: 31,
    totalEpochs: 40,
    loss: 0.128,
    accuracy: 94.1,
    lr: 0.00002,
    duration: '1h 52m',
    gpu: 'A100 x4',
    started: '2024-03-14 09:22',
  },
  {
    id: 'run-0090',
    model: 'QuantixGPT-M',
    status: 'completed',
    progress: 100,
    epoch: 25,
    totalEpochs: 25,
    loss: 0.198,
    accuracy: 91.3,
    lr: 0.00003,
    duration: '0h 47m',
    gpu: 'A100 x2',
    started: '2024-03-14 07:31',
  },
  {
    id: 'run-0089',
    model: 'RoBERTa-Finetune',
    status: 'failed',
    progress: 34,
    epoch: 9,
    totalEpochs: 25,
    loss: null,
    accuracy: null,
    lr: 0.0001,
    duration: '0h 22m',
    gpu: 'A100 x2',
    started: '2024-03-14 06:44',
  },
  {
    id: 'run-0088',
    model: 'DistilBERT-Custom',
    status: 'completed',
    progress: 100,
    epoch: 20,
    totalEpochs: 20,
    loss: 0.243,
    accuracy: 88.4,
    lr: 0.00005,
    duration: '0h 31m',
    gpu: 'V100 x2',
    started: '2024-03-13 22:14',
  },
]

export const trainingLogs = [
  { time: '10:44:32', level: 'INFO', message: 'Epoch 31/40 — loss: 0.1284 acc: 0.9412 val_loss: 0.1561 val_acc: 0.9281' },
  { time: '10:43:58', level: 'INFO', message: 'Step 3100/4000 — batch_loss: 0.1201 lr: 2e-05 eta: 0:13:21' },
  { time: '10:43:24', level: 'INFO', message: 'Step 3050/4000 — batch_loss: 0.1318 lr: 2e-05 eta: 0:14:02' },
  { time: '10:42:51', level: 'INFO', message: 'Step 3000/4000 — batch_loss: 0.1267 lr: 2e-05 eta: 0:14:41' },
  { time: '10:42:17', level: 'INFO', message: 'Epoch 30/40 complete — saving checkpoint to /models/quantix-bert-l/ckpt-30' },
  { time: '10:41:44', level: 'WARN', message: 'GPU memory at 94% — consider reducing batch size if OOM occurs' },
  { time: '10:41:10', level: 'INFO', message: 'Step 2950/4000 — batch_loss: 0.1392 lr: 2e-05 eta: 0:15:22' },
  { time: '10:40:37', level: 'INFO', message: 'Learning rate scheduler: cosine annealing step 29/39' },
  { time: '10:40:03', level: 'INFO', message: 'Step 2900/4000 — batch_loss: 0.1428 lr: 2.1e-05 eta: 0:16:01' },
  { time: '10:39:29', level: 'ERROR', message: 'Gradient clipping triggered at step 2891 — norm: 4.218 > max_norm: 1.0' },
  { time: '10:38:56', level: 'INFO', message: 'Step 2850/4000 — batch_loss: 0.1471 lr: 2.2e-05 eta: 0:16:43' },
]

// GPU data
export const gpuData = [
  { name: 'A100-SXM4-0', utilization: 94, vram: 78, temperature: 72, power: 312, status: 'active' },
  { name: 'A100-SXM4-1', utilization: 91, vram: 76, temperature: 69, power: 298, status: 'active' },
  { name: 'A100-SXM4-2', utilization: 88, vram: 71, temperature: 74, power: 287, status: 'active' },
  { name: 'A100-SXM4-3', utilization: 86, vram: 68, temperature: 67, power: 274, status: 'active' },
  { name: 'V100-16G-0', utilization: 12, vram: 18, temperature: 41, power: 82, status: 'idle' },
  { name: 'V100-16G-1', utilization: 0, vram: 4, temperature: 38, power: 24, status: 'offline' },
]

export const gpuTimeline = Array.from({ length: 30 }, (_, i) => ({
  time: `${String(10 + Math.floor(i / 2)).padStart(2,'0')}:${i%2===0?'00':'30'}`,
  'A100-0': 85 + Math.random() * 15,
  'A100-1': 82 + Math.random() * 15,
  'A100-2': 78 + Math.random() * 15,
  'V100-0': 8 + Math.random() * 20,
}))

export const gpuMemoryTimeline = Array.from({ length: 30 }, (_, i) => ({
  time: `${String(10 + Math.floor(i / 2)).padStart(2,'0')}:${i%2===0?'00':'30'}`,
  used: 62 + Math.random() * 20,
  free: 18 - Math.random() * 6,
}))

// Experiments
export const experiments = [
  {
    id: 'exp-0047',
    name: 'BERT-L Cosine LR + WarmupDecay',
    model: 'QuantixBERT-L',
    status: 'completed',
    metric: 94.7,
    params: { lr: 2e-5, batch: 32, epochs: 40, warmup: 0.1 },
    created: '2024-03-14',
    duration: '2h 34m',
    rank: 1,
    tags: ['cosine-lr', 'warmup'],
  },
  {
    id: 'exp-0046',
    name: 'BERT-L Cyclic LR Experiment',
    model: 'QuantixBERT-L',
    status: 'completed',
    metric: 93.9,
    params: { lr: 3e-5, batch: 32, epochs: 35, warmup: 0.05 },
    created: '2024-03-13',
    duration: '2h 11m',
    rank: 2,
    tags: ['cyclic-lr'],
  },
  {
    id: 'exp-0045',
    name: 'GPT-M Standard Training Run',
    model: 'QuantixGPT-M',
    status: 'completed',
    metric: 91.3,
    params: { lr: 3e-5, batch: 64, epochs: 25, warmup: 0.1 },
    created: '2024-03-14',
    duration: '0h 47m',
    rank: 3,
    tags: ['baseline'],
  },
  {
    id: 'exp-0044',
    name: 'RoBERTa High LR Ablation',
    model: 'RoBERTa-Base',
    status: 'failed',
    metric: null,
    params: { lr: 1e-4, batch: 128, epochs: 20, warmup: 0 },
    created: '2024-03-14',
    duration: '0h 22m',
    rank: null,
    tags: ['high-lr', 'ablation'],
  },
  {
    id: 'exp-0043',
    name: 'DistilBERT Knowledge Distillation',
    model: 'DistilBERT',
    status: 'completed',
    metric: 88.4,
    params: { lr: 5e-5, batch: 64, epochs: 20, warmup: 0.1 },
    created: '2024-03-13',
    duration: '0h 31m',
    rank: 4,
    tags: ['distillation', 'compression'],
  },
]

export const hyperparamComparison = [
  { name: 'exp-0047', accuracy: 94.7, f1: 92.5, loss: 0.084, lr: '2e-5', batch: 32 },
  { name: 'exp-0046', accuracy: 93.9, f1: 91.8, loss: 0.096, lr: '3e-5', batch: 32 },
  { name: 'exp-0045', accuracy: 91.3, f1: 89.8, loss: 0.198, lr: '3e-5', batch: 64 },
  { name: 'exp-0043', accuracy: 88.4, f1: 86.2, loss: 0.243, lr: '5e-5', batch: 64 },
]

// Predictions
export const predictionData = {
  successRate: 97.3,
  avgConfidence: 0.912,
  totalPredictions: 2847293,
  predictionsToday: 48291,
  avgLatency: 42,
  errorRate: 2.7,
}

export const predictionTimeline = Array.from({ length: 24 }, (_, i) => ({
  hour: `${String(i).padStart(2,'0')}:00`,
  predictions: Math.floor(1200 + Math.random() * 2800),
  errors: Math.floor(30 + Math.random() * 120),
  avgConfidence: 0.88 + Math.random() * 0.1,
}))

export const confidenceDistribution = [
  { range: '0.0–0.1', count: 1247 },
  { range: '0.1–0.2', count: 2841 },
  { range: '0.2–0.3', count: 4312 },
  { range: '0.3–0.4', count: 6847 },
  { range: '0.4–0.5', count: 9234 },
  { range: '0.5–0.6', count: 14821 },
  { range: '0.6–0.7', count: 28473 },
  { range: '0.7–0.8', count: 52841 },
  { range: '0.8–0.9', count: 98234 },
  { range: '0.9–1.0', count: 187429 },
]

export const realtimePredictions = [
  { id: 'pred-8821', input: 'This product completely exceeded my expectations...', label: 'Positive', confidence: 0.994, latency: 38, time: '10:44:51' },
  { id: 'pred-8820', input: 'Terrible experience, never ordering again from...', label: 'Negative', confidence: 0.987, latency: 41, time: '10:44:49' },
  { id: 'pred-8819', input: 'The delivery was on time and the package was...', label: 'Neutral', confidence: 0.872, latency: 44, time: '10:44:47' },
  { id: 'pred-8818', input: 'Average quality, nothing special but it works...', label: 'Neutral', confidence: 0.741, latency: 39, time: '10:44:45' },
  { id: 'pred-8817', input: 'Absolutely love this! Best purchase I have made...', label: 'Positive', confidence: 0.998, latency: 36, time: '10:44:43' },
  { id: 'pred-8816', input: 'Kind of disappointed with the build quality but...', label: 'Negative', confidence: 0.823, latency: 43, time: '10:44:41' },
]

// User management
export const users = [
  { id: 'usr-001', name: 'Elena Vasquez', email: 'e.vasquez@quantix.ai', role: 'Admin', team: 'Core ML', status: 'active', joined: '2023-01-12', lastActive: '2 min ago', models: 14, avatar: 'EV' },
  { id: 'usr-002', name: 'Marcus Chen', email: 'm.chen@quantix.ai', role: 'ML Engineer', team: 'Core ML', status: 'active', joined: '2023-02-28', lastActive: '1h ago', models: 8, avatar: 'MC' },
  { id: 'usr-003', name: 'Priya Nair', email: 'p.nair@quantix.ai', role: 'Data Scientist', team: 'Research', status: 'active', joined: '2023-04-15', lastActive: '3h ago', models: 11, avatar: 'PN' },
  { id: 'usr-004', name: 'Jordan Blake', email: 'j.blake@quantix.ai', role: 'ML Engineer', team: 'Platform', status: 'inactive', joined: '2023-06-01', lastActive: '2 days ago', models: 3, avatar: 'JB' },
  { id: 'usr-005', name: 'Sasha Müller', email: 's.muller@quantix.ai', role: 'Researcher', team: 'Research', status: 'active', joined: '2024-01-08', lastActive: '5 min ago', models: 6, avatar: 'SM' },
  { id: 'usr-006', name: 'Aiden Park', email: 'a.park@quantix.ai', role: 'Data Engineer', team: 'Data', status: 'active', joined: '2024-02-20', lastActive: '22 min ago', models: 2, avatar: 'AP' },
]

// API Keys
export const apiKeys = [
  { id: 'key-001', name: 'Production API — Main', key: 'qx_live_k7f9...m3p2', scope: 'full', status: 'active', created: '2024-01-15', lastUsed: '2 min ago', requests: 2847293 },
  { id: 'key-002', name: 'Staging Environment', key: 'qx_test_a2d4...k8r1', scope: 'read', status: 'active', created: '2024-02-01', lastUsed: '4h ago', requests: 142847 },
  { id: 'key-003', name: 'Analytics Integration', key: 'qx_live_n9c1...w7q5', scope: 'predictions', status: 'active', created: '2024-02-14', lastUsed: '1h ago', requests: 891234 },
  { id: 'key-004', name: 'CI/CD Pipeline', key: 'qx_live_p4m8...t6y3', scope: 'training', status: 'active', created: '2024-03-01', lastUsed: '6h ago', requests: 48291 },
  { id: 'key-005', name: 'Dev Environment — Local', key: 'qx_test_z2b6...h9r4', scope: 'full', status: 'revoked', created: '2023-12-20', lastUsed: '30 days ago', requests: 28472 },
]

// System logs
export const systemLogs = [
  { id: 1, time: '10:44:52', level: 'INFO', service: 'inference-api', message: 'Prediction request processed — model: quantix-bert-l-v2.4.1 latency: 38ms' },
  { id: 2, time: '10:44:41', level: 'INFO', service: 'training-worker', message: 'Checkpoint saved — run: run-0091 epoch: 31/40' },
  { id: 3, time: '10:44:28', level: 'WARN', service: 'gpu-monitor', message: 'A100-SXM4-0 temperature reached 72°C — threshold: 75°C' },
  { id: 4, time: '10:44:15', level: 'INFO', service: 'dataset-service', message: 'Dataset ds-002 processing progress: 67% complete' },
  { id: 5, time: '10:43:52', level: 'ERROR', service: 'training-worker', message: 'Run run-0089 failed — OutOfMemoryError at step 847 epoch 9' },
  { id: 6, time: '10:43:39', level: 'INFO', service: 'auth-service', message: 'API key qx_live_k7f9...m3p2 authenticated — endpoint: /v1/predict' },
  { id: 7, time: '10:43:26', level: 'INFO', service: 'model-registry', message: 'Model quantix-bert-l-v2.4.1 deployed to production cluster' },
  { id: 8, time: '10:43:13', level: 'WARN', service: 'inference-api', message: 'High request volume detected — rate: 2847 req/min approaching limit: 3000' },
  { id: 9, time: '10:42:59', level: 'INFO', service: 'experiment-tracker', message: 'Experiment exp-0047 completed — best_accuracy: 94.7% saved to registry' },
  { id: 10, time: '10:42:46', level: 'INFO', service: 'data-pipeline', message: 'Batch ingestion complete — records: 48291 dataset: SentimentCorpus-EN-2024' },
  { id: 11, time: '10:42:32', level: 'ERROR', service: 'scheduler', message: 'Job qx-retrain-weekly failed to start — insufficient GPU capacity' },
  { id: 12, time: '10:42:18', level: 'INFO', service: 'auth-service', message: 'New user login — user: s.muller@quantix.ai IP: 192.168.1.84' },
]

// Notifications
export const notifications = [
  { id: 1, type: 'success', title: 'Training Complete', message: 'Run run-0090 (QuantixGPT-M) reached 91.3% accuracy', time: '2 min ago', read: false },
  { id: 2, type: 'warning', title: 'High GPU Temperature', message: 'A100-SXM4-0 is running at 72°C — monitor closely', time: '15 min ago', read: false },
  { id: 3, type: 'error', title: 'Training Run Failed', message: 'Run run-0089 failed with OOM error at epoch 9', time: '1h ago', read: false },
  { id: 4, type: 'info', title: 'Model Deployed', message: 'QuantixBERT-L v2.4.1 is now live in production', time: '2h ago', read: true },
  { id: 5, type: 'success', title: 'Dataset Ready', message: 'SentimentCorpus-EN-2024 has finished processing', time: '3h ago', read: true },
  { id: 6, type: 'info', title: 'API Limit Warning', message: 'Approaching 90% of monthly prediction quota', time: '5h ago', read: true },
  { id: 7, type: 'success', title: 'Experiment Milestone', message: 'exp-0047 set new accuracy record: 94.7%', time: '6h ago', read: true },
]

// Billing
export const billingData = {
  plan: 'Enterprise',
  status: 'active',
  nextBilling: '2024-04-14',
  amount: 2499,
  usage: {
    predictions: { used: 2847293, limit: 5000000, percentage: 56.9 },
    training: { used: 847, limit: 1000, percentage: 84.7 },
    storage: { used: 284.7, limit: 500, percentage: 56.9 },
    apiCalls: { used: 3891234, limit: 10000000, percentage: 38.9 },
  }
}

export const billingHistory = [
  { id: 'inv-2024-03', date: '2024-03-14', amount: 2499, status: 'pending', period: 'Mar 2024' },
  { id: 'inv-2024-02', date: '2024-02-14', amount: 2499, status: 'paid', period: 'Feb 2024' },
  { id: 'inv-2024-01', date: '2024-01-14', amount: 2499, status: 'paid', period: 'Jan 2024' },
  { id: 'inv-2023-12', date: '2023-12-14', amount: 1899, status: 'paid', period: 'Dec 2023' },
  { id: 'inv-2023-11', date: '2023-11-14', amount: 1899, status: 'paid', period: 'Nov 2023' },
]

// Summary KPIs for main dashboard
export const kpis = [
  { label: 'Active Models', value: '12', change: +2, changeLabel: 'vs last month', color: 'violet' },
  { label: 'Predictions Today', value: '48.3K', change: +12.4, changeLabel: 'vs yesterday', color: 'cyan' },
  { label: 'Avg Accuracy', value: '94.7%', change: +1.8, changeLabel: 'vs last run', color: 'emerald' },
  { label: 'GPU Utilization', value: '89.7%', change: -3.2, changeLabel: 'vs 1h ago', color: 'amber' },
]

export const recentActivity = [
  { id: 1, user: 'Elena V.', action: 'deployed', target: 'QuantixBERT-L v2.4.1', time: '2 min ago', avatar: 'EV' },
  { id: 2, user: 'System', action: 'completed training', target: 'run-0090 (GPT-M)', time: '47 min ago', avatar: 'SY' },
  { id: 3, user: 'Priya N.', action: 'uploaded dataset', target: 'SentimentCorpus-EN-2024', time: '1h ago', avatar: 'PN' },
  { id: 4, user: 'Marcus C.', action: 'started experiment', target: 'exp-0047', time: '3h ago', avatar: 'MC' },
  { id: 5, user: 'System', action: 'auto-scaled GPU', target: 'Training cluster A', time: '4h ago', avatar: 'SY' },
  { id: 6, user: 'Sasha M.', action: 'created API key', target: 'CI/CD Pipeline', time: '6h ago', avatar: 'SM' },
]
